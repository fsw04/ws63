/*
 * Description: SLE 1VN Client - ported from official sle_demo_1vn.
 *   1 master connects to N slaves.
 */

#ifndef SLE_1VN_CLIENT_H
#define SLE_1VN_CLIENT_H

#include "sle_ssap_client.h"

#define NFC_NAME_MAX_LEN   32
#define NFC_ID_MAX_LEN     20
#define NFC_QUEUE_SIZE     16

typedef struct {
    char name[NFC_NAME_MAX_LEN];
    char id_number[NFC_ID_MAX_LEN];
} nfc_identity_t;

typedef struct {
    uint16_t conn_id;
    sle_addr_t peer_addr;
    ssapc_find_service_result_t find_service_result;
    nfc_identity_t identity;
    uint8_t identity_assigned;
    uint8_t busy;
} sle_conn_and_service_t;

/*
 * 设备状态快照，供外部硬件显示模块调用
 * 调用 sle_1vn_get_device_status(index, &status) 填充
 */
typedef struct {
    uint16_t conn_id;
    uint8_t  is_busy;
    uint8_t  mac[6];
    char     name[NFC_NAME_MAX_LEN];
    char     id_number[NFC_ID_MAX_LEN];
} sle_1vn_device_status_t;

/* NFC 身份接收回调, PN532 模块就绪后触发 */
typedef void (*nfc_identity_callback_t)(const char *name, const char *id_number);

void sle_1vn_client_init(void);
void sle_1vn_start_scan(void);
uint8_t sle_1vn_is_service_ready(void);
int sle_1vn_client_send_data(uint8_t *data, uint8_t length);
sle_conn_and_service_t *sle_1vn_get_conn_and_service(void);
ssapc_write_param_t *sle_1vn_get_send_param(void);

/*
 * NFC 身份信息接口 (空函数, 待 PN532 就绪后实现)
 * 外部调用: nfc_on_identity_received("张三", "130102199001011234");
 * 主控端会自动发送到下一个未分配的可穿戴设备
 */
void nfc_on_identity_received(const char *name, const char *id_number);
void sle_1vn_register_nfc_callback(nfc_identity_callback_t cb);
int sle_1vn_send_identity_to_device(int device_index, const char *name, const char *id_number);
uint8_t sle_1vn_get_conn_count(void);
int sle_1vn_find_idle_device(void);
void sle_1vn_mark_device_busy(uint16_t conn_id);
void sle_1vn_print_device_status(void);

/*
 * 硬件显示接口 — 获取指定索引设备的状态快照
 * 返回 0 成功, -1 索引无效。供 OLED/LCD 等外设调用
 */
int sle_1vn_get_device_status(int index, sle_1vn_device_status_t *out);

/*
 * 触控屏精准分配接口
 * 查询第 index 个设备是否空闲 (0=忙, 1=空闲, -1=索引无效)
 */
int sle_1vn_is_device_idle(int index);

/*
 * 将身份信息精准分配到指定设备
 * 外部调用示例: sle_1vn_assign_identity_to_device(0, "张三", "130102199001011234");
 * 返回 0 成功, -1 失败 (索引无效/设备忙/服务未就绪)
 */
int sle_1vn_assign_identity_to_device(int index, const char *name, const char *id_number);

/*
 * 触控屏分配接口 — 从 NFC 队列取出身份分配到指定设备
 * 返回 0 成功, -1 队列空/设备不可分配
 * 用法: a 0  ← 串口命令, 队列里必须已有 NFC 刷卡数据
 */
int sle_1vn_assign_from_queue_to_device(int index);

/*
 * 解绑指定设备 — 清除 Server 端的身份信息，Client 端恢复空闲
 * 返回 0 成功, -1 设备无效/未分配
 * 用法: u 0
 */
int sle_1vn_unbind_device(int index);

/*
 * NFC 读卡队列 (PN532 模块就绪后调用 nfc_queue_push 存入)
 * 队列容量 NFC_QUEUE_SIZE, FIFO 先进先出
 */
int nfc_queue_push(const char *name, const char *id_number);
int nfc_queue_pop(char *name_out, uint8_t name_max, char *id_out, uint8_t id_max);
int nfc_queue_is_empty(void);
int nfc_queue_count(void);

/*
 * ================ 触控屏统一接口 ================
 * 外部模块只需 include "sle_1vn_client.h" 即可调用以下全部接口
 */

/* 连接管理 */
uint8_t sle_1vn_get_conn_count(void);
int     sle_1vn_get_device_status(int index, sle_1vn_device_status_t *out);
int     sle_1vn_is_device_idle(int index);

/* NFC 刷卡入口 — PN532 读卡后调用, 存入队列 */
int     sle_1vn_nfc_card_push(const char *name, const char *id_number);

/* 队列查询 */
int     sle_1vn_queue_count(void);

/* 绑定: 从队列取身份分配到指定设备 */
int     sle_1vn_bind_device(int index);

/* 解绑: 清除指定设备的身份信息 */
int     sle_1vn_unbind_device(int index);

/* 串口调试 */
void    sle_1vn_print_device_status(void);

#endif
