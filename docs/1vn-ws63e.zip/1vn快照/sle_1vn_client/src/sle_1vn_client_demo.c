/*
 * SLE NFC Wearable Master Demo — 串口命令模式
 * 上电连接 Server，预载测试患者到队列，a <idx> 分配队列中的身份
 *
 * 命令: a <index>  分配队列首位身份到设备
 *        s         打印设备状态
 *        q         查看队列
 *        h         帮助
 */
#include <stdio.h>
#include <string.h>
#include "securec.h"
#include "uart.h"
#include "soc_osal.h"
#include "app_init.h"
#include "common_def.h"
#include "../inc/sle_1vn_client.h"

#define CONSOLE_UART_BUS  UART_BUS_0
#define CMD_BUF_SIZE      128

static char g_cmd_buf[CMD_BUF_SIZE];

static int serial_read_line(void)
{
    uint8_t ch;
    int32_t n;
    int i;

    (void)memset_s(g_cmd_buf, CMD_BUF_SIZE, 0, CMD_BUF_SIZE);

    n = uapi_uart_read(CONSOLE_UART_BUS, &ch, 1, 30);
    if (n != 1) {
        return 0;
    }
    if (ch < 0x20) {
        return 0;
    }
    g_cmd_buf[0] = (char)ch;

    for (i = 1; i < (CMD_BUF_SIZE - 1); i++) {
        n = uapi_uart_read(CONSOLE_UART_BUS, &ch, 1, 10);
        if (n != 1) {
            break;
        }
        if (ch == '\r' || ch == '\n') {
            g_cmd_buf[i] = '\0';
            osal_printk("\r\n[cmd] %s\r\n", g_cmd_buf);
            return 1;
        }
        if (ch >= 0x20) {
            g_cmd_buf[i] = (char)ch;
        }
    }
    return 0;
}

static int serial_find_index_by_mac_byte(uint8_t mac_byte)
{
    int count = sle_1vn_get_conn_count();
    int i;
    for (i = 0; i < count; i++) {
        sle_1vn_device_status_t s;
        sle_1vn_get_device_status(i, &s);
        if (s.mac[5] == mac_byte) {
            return i;
        }
    }
    return -1;
}

static int serial_parse_hex_byte(const char *s)
{
    int val = 0;
    while (*s != '\0' && *s != ' ') {
        val <<= 4;
        if (*s >= '0' && *s <= '9') {
            val |= (*s - '0');
        } else if (*s >= 'a' && *s <= 'f') {
            val |= (*s - 'a' + 10);
        } else if (*s >= 'A' && *s <= 'F') {
            val |= (*s - 'A' + 10);
        } else {
            break;
        }
        s++;
    }
    return val;
}

static void serial_cmd_parse(void)
{
    if (g_cmd_buf[0] == 'h') {
        osal_printk("=== Help ===\r\n");
        osal_printk("a <mac>  - assign to MAC (e.g. a 45)\r\n");
        osal_printk("u <mac>  - unbind from MAC\r\n");
        osal_printk("s        - device status\r\n");
        osal_printk("q        - queue status\r\n");
        osal_printk("h        - help\r\n");
    } else if (g_cmd_buf[0] == 's') {
        sle_1vn_print_device_status();
    } else if (g_cmd_buf[0] == 'q') {
        osal_printk("[queue] %d identity(s) waiting\r\n", sle_1vn_queue_count());
    } else if (g_cmd_buf[0] == 'a' && g_cmd_buf[1] == ' ') {
        int mac_byte = serial_parse_hex_byte(g_cmd_buf + 2);
        int idx = serial_find_index_by_mac_byte((uint8_t)mac_byte);
        if (idx < 0) {
            osal_printk("[cmd] MAC 0x%02x not found\r\n", mac_byte);
        } else {
            int ret = sle_1vn_bind_device(idx);
            if (ret == 0) {
                osal_printk("[cmd] assigned OK to MAC 0x%02x\r\n", mac_byte);
                sle_1vn_print_device_status();
            } else {
                osal_printk("[cmd] assign FAILED (ret=%d)\r\n", ret);
            }
        }
    } else if (g_cmd_buf[0] == 'u' && g_cmd_buf[1] == ' ') {
        int mac_byte = serial_parse_hex_byte(g_cmd_buf + 2);
        int idx = serial_find_index_by_mac_byte((uint8_t)mac_byte);
        if (idx < 0) {
            osal_printk("[cmd] MAC 0x%02x not found\r\n", mac_byte);
        } else {
            int ret = sle_1vn_unbind_device(idx);
            if (ret == 0) {
                osal_printk("[cmd] unbind OK\r\n");
                sle_1vn_print_device_status();
            } else {
                osal_printk("[cmd] unbind FAILED (ret=%d)\r\n", ret);
            }
        }
    }
}

static int sle_1vn_client_demo_task(const char *arg)
{
    unused(arg);

    osal_printk("=== SLE Wearable Master (UART CMD) ===\r\n");

    sle_1vn_client_init();

    osal_printk("[demo] waiting for all wearables...\r\n");
    while (!sle_1vn_is_service_ready()) {
        osal_msleep(500);
    }
    osal_printk("[demo] %d device(s) online\r\n", sle_1vn_get_conn_count());

    sle_1vn_nfc_card_push("秋雨", "772616166277377737");
    sle_1vn_nfc_card_push("违建", "882871888277364587");
    osal_printk("[demo] 2 test patients preloaded into queue\r\n");
    osal_printk("CMD: a <mac> | u <mac> | s=status | q=queue | h=help\r\n");

    sle_1vn_print_device_status();

    int tick = 0;
    while (1) {
        if (serial_read_line()) {
            serial_cmd_parse();
        }
        osal_msleep(100);
        tick++;
        if (tick >= 100) {
            tick = 0;
            sle_1vn_print_device_status();
        }
    }
    return 0;
}

static void sle_1vn_client_demo_entry(void)
{
    osal_task *task_handle = NULL;
    osal_kthread_lock();
    task_handle = osal_kthread_create((osal_kthread_handler)sle_1vn_client_demo_task, 0,
                                      "sle_1vn_demo", 0x4000);
    if (task_handle != NULL) {
        osal_kthread_set_priority(task_handle, 26);
        osal_kfree(task_handle);
    }
    osal_kthread_unlock();
}

app_run(sle_1vn_client_demo_entry);
