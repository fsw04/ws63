/*
 * Ported from official sle_demo_1vn/sle_client.c
 * Adapted to WS63 SDK API (lowercase_underscore naming).
 * 1 master connects to N slaves via name-based scan.
 */
#include <string.h>
#include "securec.h"
#include "common_def.h"
#include "soc_osal.h"
#include "app_init.h"
#include "sle_device_discovery.h"
#include "sle_connection_manager.h"
#include "sle_ssap_client.h"
#include "../inc/sle_1vn_client.h"

#define SLE_MTU_SIZE_DEFAULT       512
#define SLE_SEEK_INTERVAL_DEFAULT  100
#define SLE_SEEK_WINDOW_DEFAULT    100
#define UUID_16BIT_LEN             2
#define UUID_128BIT_LEN            16
#define SLE_TASK_DELAY_MS          1000
#define SLE_CLIENT_LOG             "[sle 1vn client]"

static sle_conn_and_service_t g_conn_and_service_arr[128];
static uint8_t g_num_conn = 0;
static uint8_t g_client_id = 0;
static sle_addr_t g_pending_addr;
static volatile uint8_t g_busy = 0;
static nfc_identity_callback_t g_nfc_callback = NULL;
static sle_announce_seek_callbacks_t g_seek_cbk = {0};
static sle_connection_callbacks_t g_connect_cbk = {0};
static ssapc_callbacks_t g_ssapc_cbk = {0};
static ssapc_write_param_t g_sle_send_param = {0};

/*
 * Add more server MACs here for 1-to-N testing:
 * Server 2: {0x78, 0x70, 0x60, 0x88, 0x96, 0x46}
 * Server 3: {0x78, 0x70, 0x60, 0x88, 0x96, 0x47}
 */
static const uint8_t g_sle_server_mac_list[][SLE_ADDR_LEN] = {
    {0x78, 0x70, 0x60, 0x88, 0x96, 0x45},
    {0x78, 0x70, 0x60, 0x88, 0x96, 0x46},
};
#define SLE_SERVER_MAC_COUNT 2

static nfc_identity_t g_nfc_queue[NFC_QUEUE_SIZE];
static uint8_t         g_nfc_queue_head = 0;
static uint8_t         g_nfc_queue_tail = 0;
static uint8_t         g_nfc_queue_len  = 0;

static void sle_client_pair_complete_cbk(uint16_t conn_id, const sle_addr_t *addr, errcode_t status);
static void sle_1vn_clear_device(uint16_t conn_id);

static int mac_is_connected(const uint8_t *mac)
{
    int i;
    for (i = 0; i < g_num_conn; i++) {
        if (memcmp(g_conn_and_service_arr[i].peer_addr.addr, mac, SLE_ADDR_LEN) == 0) {
            return 1;
        }
    }
    return 0;
}

sle_conn_and_service_t *sle_1vn_get_conn_and_service(void)
{
    return g_conn_and_service_arr;
}

uint8_t sle_1vn_is_service_ready(void)
{
    int i;
    for (i = 0; i < g_num_conn; i++) {
        if (g_conn_and_service_arr[i].find_service_result.start_hdl != 0) {
            return 1;
        }
    }
    return 0;
}

ssapc_write_param_t *sle_1vn_get_send_param(void)
{
    return &g_sle_send_param;
}

void sle_1vn_start_scan(void)
{
    sle_seek_param_t param = {0};
    param.own_addr_type = 0;
    param.filter_duplicates = 0;
    param.seek_filter_policy = 0;
    param.seek_phys = 1;
    param.seek_type[0] = 0;
    param.seek_interval[0] = SLE_SEEK_INTERVAL_DEFAULT;
    param.seek_window[0] = SLE_SEEK_WINDOW_DEFAULT;
    sle_set_seek_param(&param);
    sle_start_seek();
}

static void sle_client_sle_enable_cbk(errcode_t status)
{
    if (status != ERRCODE_SUCC) {
        osal_printk("%s sle_enable_cbk status error\r\n", SLE_CLIENT_LOG);
    } else {
        osal_msleep(SLE_TASK_DELAY_MS);
        sle_1vn_start_scan();
    }
}

static void sle_client_seek_enable_cbk(errcode_t status)
{
    if (status != ERRCODE_SUCC) {
        osal_printk("%s seek_enable_cbk status error\r\n", SLE_CLIENT_LOG);
    }
}

static void sle_client_seek_result_info_cbk(sle_seek_result_info_t *seek_result_data)
{
    int m;
    if (seek_result_data == NULL) {
        return;
    }

    for (m = 0; m < SLE_SERVER_MAC_COUNT; m++) {
        if (memcmp(seek_result_data->addr.addr, g_sle_server_mac_list[m], SLE_ADDR_LEN) == 0) {
            if (g_busy) {
                break;
            }
            if (mac_is_connected(seek_result_data->addr.addr)) {
                break;
            }
            osal_printk("%s target[%d] found, stopping scan to connect...\r\n", SLE_CLIENT_LOG, m);
            (void)memcpy_s(&g_pending_addr, sizeof(sle_addr_t),
                           &seek_result_data->addr, sizeof(sle_addr_t));
            g_busy = 1;
            sle_stop_seek();
            break;
        }
    }
}

static void sle_client_seek_disable_cbk(errcode_t status)
{
    osal_printk("%s seek_disable, status:0x%x\r\n", SLE_CLIENT_LOG, status);
    if (status == ERRCODE_SUCC) {
        sle_remove_paired_remote_device(&g_pending_addr);
        sle_connect_remote_device(&g_pending_addr);
    }
}

static void sle_client_seek_cbk_register(void)
{
    g_seek_cbk.sle_enable_cb = sle_client_sle_enable_cbk;
    g_seek_cbk.seek_enable_cb = sle_client_seek_enable_cbk;
    g_seek_cbk.seek_result_cb = sle_client_seek_result_info_cbk;
    g_seek_cbk.seek_disable_cb = sle_client_seek_disable_cbk;
    sle_announce_seek_register_callbacks(&g_seek_cbk);
}

static void sle_client_connect_state_changed_cbk(uint16_t conn_id, const sle_addr_t *addr,
    sle_acb_state_t conn_state, sle_pair_state_t pair_state, sle_disc_reason_t disc_reason)
{
    osal_printk("%s conn_state_changed conn_id:0x%02x, conn_state:0x%x, pair_state:0x%x, disc_reason:0x%x\r\n",
                SLE_CLIENT_LOG, conn_id, conn_state, pair_state, disc_reason);
    osal_printk("%s addr:%02x:%02x:%02x:%02x:%02x:%02x\r\n",
                SLE_CLIENT_LOG, addr->addr[0], addr->addr[1], addr->addr[2],
                addr->addr[3], addr->addr[4], addr->addr[5]);

    if (conn_state == SLE_ACB_STATE_CONNECTED) {
        int idx = g_num_conn;
        g_conn_and_service_arr[idx].conn_id = conn_id;
        (void)memcpy_s(&g_conn_and_service_arr[idx].peer_addr,
                       sizeof(sle_addr_t), addr, sizeof(sle_addr_t));
        g_num_conn++;
        osal_printk("%s SLE_ACB_STATE_CONNECTED total:%d pair_state:0x%x\r\n",
                    SLE_CLIENT_LOG, g_num_conn, pair_state);
        if (pair_state == SLE_PAIR_NONE) {
            osal_printk("%s initiating pair\r\n", SLE_CLIENT_LOG);
            sle_pair_remote_device(&g_conn_and_service_arr[idx].peer_addr);
        }

    } else if (conn_state == SLE_ACB_STATE_NONE) {
        osal_printk("%s SLE_ACB_STATE_NONE\r\n", SLE_CLIENT_LOG);

    } else if (conn_state == SLE_ACB_STATE_DISCONNECTED) {
        g_busy = 0;
        osal_printk("%s SLE_ACB_STATE_DISCONNECTED\r\n", SLE_CLIENT_LOG);

        int i;
        for (i = 0; i < g_num_conn; i++) {
            if (g_conn_and_service_arr[i].conn_id == conn_id) {
                int j;
                for (j = i; j < g_num_conn - 1; j++) {
                    g_conn_and_service_arr[j] = g_conn_and_service_arr[j + 1];
                }
                (void)memset_s(&g_conn_and_service_arr[j], sizeof(sle_conn_and_service_t),
                               0, sizeof(sle_conn_and_service_t));
                g_num_conn--;
            }
        }
    } else {
        osal_printk("%s status error\r\n", SLE_CLIENT_LOG);
    }
}

static void sle_client_connect_cbk_register(void)
{
    g_connect_cbk.connect_state_changed_cb = sle_client_connect_state_changed_cbk;
    g_connect_cbk.pair_complete_cb = sle_client_pair_complete_cbk;
    sle_connection_register_callbacks(&g_connect_cbk);
}

static void sle_client_pair_complete_cbk(uint16_t conn_id, const sle_addr_t *addr, errcode_t status)
{
    osal_printk("%s pair complete conn:0x%x, status:0x%x\r\n", SLE_CLIENT_LOG, conn_id, status);
    if (status == ERRCODE_SUCC) {
        ssap_exchange_info_t info = {0};
        info.mtu_size = SLE_MTU_SIZE_DEFAULT;
        info.version = 1;
        ssapc_exchange_info_req(0, conn_id, &info);
        g_busy = 0;
        sle_1vn_start_scan();
    } else {
        osal_printk("%s pair FAILED, disconnecting\r\n", SLE_CLIENT_LOG);
        sle_remove_paired_remote_device(addr);
        sle_disconnect_remote_device(addr);
        g_busy = 0;
        sle_1vn_start_scan();
    }
}

static void sle_client_exchange_info_cbk(uint8_t client_id, uint16_t conn_id,
    ssap_exchange_info_t *param, errcode_t status)
{
    osal_printk("%s exchange_info client_id:%d conn_id:%d status:%d\r\n",
                SLE_CLIENT_LOG, client_id, conn_id, status);
    osal_printk("%s mtu:%d, version:%d\r\n", SLE_CLIENT_LOG, param->mtu_size, param->version);

    if (status == ERRCODE_SUCC) {
        ssapc_find_structure_param_t find_param = {0};
        find_param.type = SSAP_FIND_TYPE_PRIMARY_SERVICE;
        find_param.start_hdl = 1;
        find_param.end_hdl = 0xFFFF;
        ssapc_find_structure(client_id, conn_id, &find_param);
    }
}

static void sle_client_find_structure_cbk(uint8_t client_id, uint16_t conn_id,
    ssapc_find_service_result_t *service, errcode_t status)
{
    osal_printk("%s find_structure client:%d conn_id:%d status:%d\r\n",
                SLE_CLIENT_LOG, client_id, conn_id, status);
    osal_printk("%s start_hdl:0x%02x, end_hdl:0x%02x, uuid_len:%d\r\n",
                SLE_CLIENT_LOG, service->start_hdl, service->end_hdl, service->uuid.len);

    int i;
    for (i = 0; i < g_num_conn; i++) {
        if (g_conn_and_service_arr[i].conn_id == conn_id) {
            g_conn_and_service_arr[i].find_service_result.start_hdl = service->start_hdl;
            g_conn_and_service_arr[i].find_service_result.end_hdl = service->end_hdl;
            (void)memcpy_s(&g_conn_and_service_arr[i].find_service_result.uuid,
                           sizeof(sle_uuid_t), &service->uuid, sizeof(sle_uuid_t));
        }
    }
}

static void sle_client_find_property_cbk(uint8_t client_id, uint16_t conn_id,
    ssapc_find_property_result_t *property, errcode_t status)
{
    osal_printk("%s find_property client:%d, conn:%d, op_ind:%d, desc_cnt:%d status:%d handle:%d\r\n",
                SLE_CLIENT_LOG, client_id, conn_id, property->operate_indication,
                property->descriptors_count, status, property->handle);
    g_sle_send_param.handle = property->handle;
    g_sle_send_param.type = SSAP_PROPERTY_TYPE_VALUE;
}

static void sle_client_find_structure_cmp_cbk(uint8_t client_id, uint16_t conn_id,
    ssapc_find_structure_result_t *structure_result, errcode_t status)
{
    unused(conn_id);
    osal_printk("%s find_structure_cmp client:%d status:%d type:%d uuid_len:%d\r\n",
                SLE_CLIENT_LOG, client_id, status, structure_result->type, structure_result->uuid.len);
    osal_printk("%s >>> service discovery done for conn:%d\r\n", SLE_CLIENT_LOG, conn_id);
    if (g_num_conn < SLE_SERVER_MAC_COUNT) {
        g_busy = 0;
        sle_1vn_start_scan();
    }
}

static void sle_client_write_cfm_cbk(uint8_t client_id, uint16_t conn_id,
    ssapc_write_result_t *write_result, errcode_t status)
{
    osal_printk("%s write_cfm conn_id:%d client:%d status:%d handle:%02x type:%02x\r\n",
                SLE_CLIENT_LOG, conn_id, client_id, status, write_result->handle, write_result->type);
}

static void sle_client_read_cfm_cbk(uint8_t client_id, uint16_t conn_id,
    ssapc_handle_value_t *read_data, errcode_t status)
{
    uint16_t idx;
    osal_printk("%s read_cfm client:0x%x conn:0x%x status:0x%x\r\n", SLE_CLIENT_LOG, client_id, conn_id, status);
    osal_printk("%s handle:0x%x, type:0x%x, len:0x%x\r\n", SLE_CLIENT_LOG,
                read_data->handle, read_data->type, read_data->data_len);
    for (idx = 0; idx < read_data->data_len; idx++) {
        osal_printk("%s [0x%x] 0x%02x\r\n", SLE_CLIENT_LOG, idx, read_data->data[idx]);
    }
}

static void sle_client_ssapc_notification_cbk(uint8_t client_id, uint16_t conn_id,
    ssapc_handle_value_t *data, errcode_t status)
{
    (void)client_id;
    (void)status;
    data->data[data->data_len - 1] = '\0';
    osal_printk("%s notification: %s\r\n", SLE_CLIENT_LOG, data->data);

    const uint8_t connected_prefix[] = {'C', 'O', 'N', 'N', 'E', 'C', 'T', 'E', 'D', ':'};
    if (memcmp(data->data, connected_prefix, 10) == 0) {
        sle_1vn_mark_device_busy(conn_id);
        osal_printk("%s device conn:%d marked BUSY\r\n", SLE_CLIENT_LOG, conn_id);
    }

    const uint8_t unbound_prefix[] = {'U', 'N', 'B', 'O', 'U', 'N', 'D'};
    if (memcmp(data->data, unbound_prefix, 7) == 0) {
        sle_1vn_clear_device(conn_id);
        osal_printk("%s device conn:%d UNBOUND, cleared to IDLE\r\n", SLE_CLIENT_LOG, conn_id);
    }
}

void sle_1vn_mark_device_busy(uint16_t conn_id)
{
    int i;
    for (i = 0; i < g_num_conn; i++) {
        if (g_conn_and_service_arr[i].conn_id == conn_id) {
            g_conn_and_service_arr[i].busy = 1;
            break;
        }
    }
}

static void sle_1vn_clear_device(uint16_t conn_id)
{
    int i;
    for (i = 0; i < g_num_conn; i++) {
        if (g_conn_and_service_arr[i].conn_id == conn_id) {
            g_conn_and_service_arr[i].busy = 0;
            g_conn_and_service_arr[i].identity_assigned = 0;
            (void)memset_s(&g_conn_and_service_arr[i].identity,
                           sizeof(nfc_identity_t), 0, sizeof(nfc_identity_t));
            break;
        }
    }
}

int sle_1vn_unbind_device(int index)
{
    ssapc_write_param_t param = {0};

    if (index < 0 || index >= g_num_conn) {
        osal_printk("%s unbind: invalid index %d\r\n", SLE_CLIENT_LOG, index);
        return -1;
    }
    if (g_conn_and_service_arr[index].find_service_result.end_hdl == 0) {
        osal_printk("%s unbind: device[%d] service not ready\r\n", SLE_CLIENT_LOG, index);
        return -1;
    }

    osal_printk("%s ===== Unbind device[%d] =====\r\n", SLE_CLIENT_LOG, index);

    const uint8_t unbind_msg[] = {'U', 'N', 'B', 'I', 'N', 'D'};
    param.handle = g_conn_and_service_arr[index].find_service_result.end_hdl;
    param.type = SSAP_PROPERTY_TYPE_VALUE;
    param.data_len = sizeof(unbind_msg) + 1;
    param.data = (uint8_t *)osal_vmalloc(param.data_len);
    if (param.data == NULL) {
        return -1;
    }
    (void)memcpy_s(param.data, param.data_len, unbind_msg, sizeof(unbind_msg));
    param.data[sizeof(unbind_msg)] = '\0';

    int ret = ssapc_write_req(g_client_id, g_conn_and_service_arr[index].conn_id, &param);
    osal_printk("%s unbind write_req result:%d\r\n", SLE_CLIENT_LOG, ret);
    osal_vfree(param.data);

    if (ret == ERRCODE_SUCC) {
        sle_1vn_clear_device(g_conn_and_service_arr[index].conn_id);
        osal_printk("%s device[%d] unbind sent, waiting UNBOUND reply...\r\n",
                    SLE_CLIENT_LOG, index);
        return 0;
    }
    return -1;
}

int sle_1vn_find_idle_device(void)
{
    int i;
    for (i = 0; i < g_num_conn; i++) {
        if (!g_conn_and_service_arr[i].busy &&
            !g_conn_and_service_arr[i].identity_assigned &&
            g_conn_and_service_arr[i].find_service_result.start_hdl != 0) {
            return i;
        }
    }
    return -1;
}

int sle_1vn_get_device_status(int index, sle_1vn_device_status_t *out)
{
    if (out == NULL || index < 0 || index >= g_num_conn) {
        return -1;
    }
    out->conn_id  = g_conn_and_service_arr[index].conn_id;
    out->is_busy  = g_conn_and_service_arr[index].busy;
    (void)memcpy_s(out->mac, 6, g_conn_and_service_arr[index].peer_addr.addr, 6);
    (void)strncpy_s(out->name, NFC_NAME_MAX_LEN,
                    g_conn_and_service_arr[index].identity.name,
                    NFC_NAME_MAX_LEN - 1);
    (void)strncpy_s(out->id_number, NFC_ID_MAX_LEN,
                    g_conn_and_service_arr[index].identity.id_number,
                    NFC_ID_MAX_LEN - 1);
    return 0;
}

void sle_1vn_print_device_status(void)
{
    int i;
    osal_printk("%s ======== Device Status ========\r\n", SLE_CLIENT_LOG);
    if (g_num_conn == 0) {
        osal_printk("%s   (no devices connected)\r\n", SLE_CLIENT_LOG);
        return;
    }
    for (i = 0; i < g_num_conn; i++) {
        sle_1vn_device_status_t s;
        sle_1vn_get_device_status(i, &s);
        osal_printk("%s [%d] conn:%d MAC:%02x:%02x:%02x:%02x:%02x:%02x  %s",
                    SLE_CLIENT_LOG, i, s.conn_id,
                    s.mac[0], s.mac[1], s.mac[2], s.mac[3], s.mac[4], s.mac[5],
                    s.is_busy ? "BUSY" : "IDLE");
        if (s.is_busy && s.name[0] != '\0') {
            osal_printk("  patient: %s  %s", s.name, s.id_number);
        }
        osal_printk("\r\n");
    }
}

int sle_1vn_is_device_idle(int index)
{
    if (index < 0 || index >= g_num_conn) {
        return -1;
    }
    if (g_conn_and_service_arr[index].find_service_result.start_hdl == 0) {
        return -1;
    }
    return g_conn_and_service_arr[index].busy ? 0 : 1;
}

/*
 * 精准分配身份到指定设备 (触控屏接口)
 * 外部调用示例: sle_1vn_assign_identity_to_device(0, "张三", "130102199001011234");
 */
int sle_1vn_assign_identity_to_device(int index, const char *name, const char *id_number)
{
    if (index < 0 || index >= g_num_conn) {
        osal_printk("%s assign: invalid index %d\r\n", SLE_CLIENT_LOG, index);
        return -1;
    }
    if (g_conn_and_service_arr[index].find_service_result.start_hdl == 0) {
        osal_printk("%s assign: device[%d] service not ready\r\n", SLE_CLIENT_LOG, index);
        return -1;
    }
    if (g_conn_and_service_arr[index].busy) {
        osal_printk("%s assign: device[%d] is BUSY\r\n", SLE_CLIENT_LOG, index);
        return -1;
    }

    osal_printk("%s ===== Manual Assign to device[%d] =====\r\n", SLE_CLIENT_LOG, index);
    osal_printk("%s Name: %s, ID: %s\r\n", SLE_CLIENT_LOG, name, id_number);

    if (g_nfc_callback != NULL) {
        g_nfc_callback(name, id_number);
    }

    g_conn_and_service_arr[index].identity_assigned = 1;
    g_conn_and_service_arr[index].busy = 1;
    (void)strncpy_s(g_conn_and_service_arr[index].identity.name,
                    NFC_NAME_MAX_LEN, name, NFC_NAME_MAX_LEN - 1);
    (void)strncpy_s(g_conn_and_service_arr[index].identity.id_number,
                    NFC_ID_MAX_LEN, id_number, NFC_ID_MAX_LEN - 1);

    int ret = sle_1vn_send_identity_to_device(index, name, id_number);
    osal_printk("%s >>> assigned to device[%d], ret:%d\r\n", SLE_CLIENT_LOG, index, ret);
    return ret;
}

static void sle_client_ssapc_indication_cbk(uint8_t client_id, uint16_t conn_id,
    ssapc_handle_value_t *data, errcode_t status)
{
    (void)client_id;
    (void)conn_id;
    (void)status;
    data->data[data->data_len - 1] = '\0';
    osal_printk("%s indication: %s\r\n", SLE_CLIENT_LOG, data->data);
}

static void sle_client_ssapc_cbk_register(void)
{
    g_ssapc_cbk.exchange_info_cb = sle_client_exchange_info_cbk;
    g_ssapc_cbk.find_structure_cb = sle_client_find_structure_cbk;
    g_ssapc_cbk.ssapc_find_property_cbk = sle_client_find_property_cbk;
    g_ssapc_cbk.find_structure_cmp_cb = sle_client_find_structure_cmp_cbk;
    g_ssapc_cbk.write_cfm_cb = sle_client_write_cfm_cbk;
    g_ssapc_cbk.read_cfm_cb = sle_client_read_cfm_cbk;
    g_ssapc_cbk.notification_cb = sle_client_ssapc_notification_cbk;
    g_ssapc_cbk.indication_cb = sle_client_ssapc_indication_cbk;
    ssapc_register_callbacks(&g_ssapc_cbk);
}

errcode_t sle_1vn_client_send_report_by_handle(const uint8_t *data, uint8_t len)
{
    ssapc_write_param_t param = {0};
    int ret;
    int i;
    osal_printk("%s send_report: %d conns, data:%s\r\n", SLE_CLIENT_LOG, g_num_conn, data);
    for (i = 0; i < g_num_conn; i++) {
        if (g_conn_and_service_arr[i].find_service_result.start_hdl == 0) {
            osal_printk("%s conn[%d] no service yet, skip\r\n", SLE_CLIENT_LOG, i);
            continue;
        }

        param.handle = g_conn_and_service_arr[i].find_service_result.end_hdl;
        param.type = SSAP_PROPERTY_TYPE_VALUE;
        param.data_len = len + 1;
        param.data = osal_vmalloc(param.data_len);
        if (param.data == NULL) {
            osal_printk("%s vmalloc fail\r\n", SLE_CLIENT_LOG);
            return ERRCODE_FAIL;
        }
        if (memcpy_s(param.data, param.data_len, data, len) != EOK) {
            osal_vfree(param.data);
            return ERRCODE_FAIL;
        }

        osal_printk("%s write_req conn:%d handle:0x%x\r\n",
                    SLE_CLIENT_LOG, g_conn_and_service_arr[i].conn_id, param.handle);
        ret = ssapc_write_req(g_client_id, g_conn_and_service_arr[i].conn_id, &param);
        osal_printk("%s write_req result:%d\r\n", SLE_CLIENT_LOG, ret);
        osal_vfree(param.data);
    }
    return ERRCODE_SUCC;
}

int sle_1vn_client_send_data(uint8_t *data, uint8_t length)
{
    return sle_1vn_client_send_report_by_handle(data, length);
}

uint8_t sle_1vn_get_conn_count(void)
{
    return g_num_conn;
}

void sle_1vn_register_nfc_callback(nfc_identity_callback_t cb)
{
    g_nfc_callback = cb;
}

/*
 * NFC 读卡队列 — 入队 (PN532 就绪后调用)
 * 返回 0 成功, -1 队列满
 */
int nfc_queue_push(const char *name, const char *id_number)
{
    if (g_nfc_queue_len >= NFC_QUEUE_SIZE) {
        return -1;
    }
    (void)strncpy_s(g_nfc_queue[g_nfc_queue_tail].name,
                    NFC_NAME_MAX_LEN, name, NFC_NAME_MAX_LEN - 1);
    (void)strncpy_s(g_nfc_queue[g_nfc_queue_tail].id_number,
                    NFC_ID_MAX_LEN, id_number, NFC_ID_MAX_LEN - 1);
    g_nfc_queue_tail = (g_nfc_queue_tail + 1) % NFC_QUEUE_SIZE;
    g_nfc_queue_len++;
    osal_printk("%s queue push: %s %s (%d/%d)\r\n",
                SLE_CLIENT_LOG, name, id_number, g_nfc_queue_len, NFC_QUEUE_SIZE);
    return 0;
}

/*
 * NFC 读卡队列 — 出队
 * 返回 0 成功, -1 队列空
 */
int nfc_queue_pop(char *name_out, uint8_t name_max, char *id_out, uint8_t id_max)
{
    if (g_nfc_queue_len == 0) {
        return -1;
    }
    (void)strncpy_s(name_out, name_max,
                    g_nfc_queue[g_nfc_queue_head].name, name_max - 1);
    (void)strncpy_s(id_out, id_max,
                    g_nfc_queue[g_nfc_queue_head].id_number, id_max - 1);
    g_nfc_queue_head = (g_nfc_queue_head + 1) % NFC_QUEUE_SIZE;
    g_nfc_queue_len--;
    return 0;
}

int nfc_queue_is_empty(void)
{
    return (g_nfc_queue_len == 0) ? 1 : 0;
}

int nfc_queue_count(void)
{
    return (int)g_nfc_queue_len;
}

/*
 * NFC 刷卡入口 — PN532 读到卡后调用此函数
 * 将身份信息推入队列, 等待触控屏选择设备后分配
 */
void nfc_on_identity_received(const char *name, const char *id_number)
{
    if (name == NULL || id_number == NULL) {
        return;
    }
    osal_printk("%s ===== NFC Card Detected =====\r\n", SLE_CLIENT_LOG);
    osal_printk("%s Name: %s, ID: %s\r\n", SLE_CLIENT_LOG, name, id_number);

    if (g_nfc_callback != NULL) {
        g_nfc_callback(name, id_number);
    }

    if (nfc_queue_push(name, id_number) != 0) {
        osal_printk("%s queue full, card ignored\r\n", SLE_CLIENT_LOG);
    }
}

/*
 * 触控屏选择设备后调用 — 从队列取身份并分配到指定设备
 * 返回 0 成功, -1 队列空/设备不可分配
 */
int sle_1vn_assign_from_queue_to_device(int index)
{
    char name[NFC_NAME_MAX_LEN] = {0};
    char id_number[NFC_ID_MAX_LEN] = {0};

    if (index < 0 || index >= g_num_conn) {
        osal_printk("%s assign: invalid index %d\r\n", SLE_CLIENT_LOG, index);
        return -1;
    }
    if (g_conn_and_service_arr[index].find_service_result.start_hdl == 0) {
        osal_printk("%s assign: device[%d] service not ready\r\n", SLE_CLIENT_LOG, index);
        return -1;
    }
    if (g_conn_and_service_arr[index].busy) {
        osal_printk("%s assign: device[%d] is BUSY\r\n", SLE_CLIENT_LOG, index);
        return -1;
    }

    if (nfc_queue_pop(name, sizeof(name), id_number, sizeof(id_number)) != 0) {
        osal_printk("%s queue empty, no identity to assign\r\n", SLE_CLIENT_LOG);
        return -1;
    }
    return sle_1vn_assign_identity_to_device(index, name, id_number);
}

/*
 * 发送身份信息到指定设备
 * 格式: "ID:姓名,身份证号"  (单播, 非广播)
 */
int sle_1vn_send_identity_to_device(int device_index, const char *name, const char *id_number)
{
    ssapc_write_param_t param = {0};

    if (device_index < 0 || device_index >= g_num_conn) {
        return -1;
    }
    if (g_conn_and_service_arr[device_index].find_service_result.end_hdl == 0) {
        return -1;
    }

    (void)strncpy_s(g_conn_and_service_arr[device_index].identity.name,
                    NFC_NAME_MAX_LEN, name, NFC_NAME_MAX_LEN - 1);
    (void)strncpy_s(g_conn_and_service_arr[device_index].identity.id_number,
                    NFC_ID_MAX_LEN, id_number, NFC_ID_MAX_LEN - 1);

    char buf[64];
    int n = sprintf_s(buf, sizeof(buf), "ID:%s,%s", name, id_number);
    if (n <= 0) {
        return -1;
    }

    param.handle = g_conn_and_service_arr[device_index].find_service_result.end_hdl;
    param.type = SSAP_PROPERTY_TYPE_VALUE;
    param.data_len = (uint16_t)(n + 1);
    param.data = (uint8_t *)osal_vmalloc(param.data_len);
    if (param.data == NULL) {
        return -1;
    }
    if (memcpy_s(param.data, param.data_len, buf, param.data_len) != EOK) {
        osal_vfree(param.data);
        return -1;
    }

    osal_printk("%s send identity to conn:%d: %s\r\n",
                SLE_CLIENT_LOG, g_conn_and_service_arr[device_index].conn_id, buf);
    int ret = ssapc_write_req(g_client_id, g_conn_and_service_arr[device_index].conn_id, &param);
    osal_printk("%s write_req result:%d\r\n", SLE_CLIENT_LOG, ret);
    osal_vfree(param.data);

    if (ret == ERRCODE_SUCC) {
        osal_printk("%s identity sent to device[%d]\r\n", SLE_CLIENT_LOG, device_index);
        return 0;
    }
    return -1;
}

static int sle_1vn_client_task(const char *arg)
{
    unused(arg);

    uint8_t local_addr[SLE_ADDR_LEN] = {0x13, 0x67, 0x5c, 0x07, 0x00, 0x51};
    sle_addr_t local_address;
    local_address.type = 0;
    (void)memcpy_s(local_address.addr, SLE_ADDR_LEN, local_addr, SLE_ADDR_LEN);

    osal_printk("%s local_addr:%02x:%02x:%02x:%02x:%02x:%02x\r\n",
                SLE_CLIENT_LOG, local_addr[0], local_addr[1], local_addr[2],
                local_addr[3], local_addr[4], local_addr[5]);

    sle_client_seek_cbk_register();
    sle_client_connect_cbk_register();
    sle_client_ssapc_cbk_register();

    sle_set_local_addr(&local_address);
    enable_sle();
    return 0;
}

#define SLE_CLIENT_TASK_PRIO  24
#define SLE_CLIENT_STACK_SIZE 0x4000

void sle_1vn_client_init(void)
{
    osal_task *task_handle = NULL;
    osal_kthread_lock();
    task_handle = osal_kthread_create((osal_kthread_handler)sle_1vn_client_task, 0,
                                      "sle_1vn_cli", SLE_CLIENT_STACK_SIZE);
    if (task_handle != NULL) {
        osal_kthread_set_priority(task_handle, SLE_CLIENT_TASK_PRIO);
        osal_kfree(task_handle);
    }
    osal_kthread_unlock();
}

/*
 * ================ 触控屏统一接口 ================
 * 薄封装, 便于外部模块调用
 */

int sle_1vn_nfc_card_push(const char *name, const char *id_number)
{
    return nfc_queue_push(name, id_number);
}

int sle_1vn_queue_count(void)
{
    return nfc_queue_count();
}

int sle_1vn_bind_device(int index)
{
    return sle_1vn_assign_from_queue_to_device(index);
}
