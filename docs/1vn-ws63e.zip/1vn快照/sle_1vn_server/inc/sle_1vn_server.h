/*
 * Ported from official sle_demo_1vn/sle_server.h
 */

#ifndef SLE_1VN_SERVER_H
#define SLE_1VN_SERVER_H

#include <stdint.h>
#include "sle_ssap_server.h"
#include "errcode.h"

#define SLE_UUID_SERVER_SERVICE        0x2222
#define SLE_UUID_SERVER_NTF_REPORT     0x2323
#define SLE_UUID_TEST_PROPERTIES       (SSAP_PERMISSION_READ | SSAP_PERMISSION_WRITE)
#define SLE_UUID_TEST_OPERATION_INDICATION \
    (SSAP_OPERATE_INDICATION_BIT_READ | SSAP_OPERATE_INDICATION_BIT_WRITE)
#define SLE_UUID_TEST_DESCRIPTOR       (SSAP_PERMISSION_READ | SSAP_PERMISSION_WRITE)

#define WEARABLE_NAME_MAX_LEN   32
#define WEARABLE_ID_MAX_LEN     20

typedef struct {
    char name[WEARABLE_NAME_MAX_LEN];
    char id_number[WEARABLE_ID_MAX_LEN];
    uint8_t identity_received;
} wearable_identity_t;

/* 身份信息接收回调 */
typedef void (*wearable_identity_callback_t)(const char *name, const char *id_number);

errcode_t sle_1vn_server_init(void);
errcode_t sle_1vn_server_send_notify_by_handle(const uint8_t *data, uint8_t len);
int sle_1vn_server_send_data(uint8_t *data, uint8_t length);
errcode_t sle_1vn_enable_server_cbk(void);
void sle_1vn_wait_client_paired(void);
void sle_1vn_wait_client_connected(void);

/*
 * 可穿戴设备端 NFC 身份信息接口 (空函数, 待 PN532 就绪后实现)
 * 收到主控端发来的 "ID:姓名,身份证号" 后解析并存储
 */
wearable_identity_t *wearable_get_identity(void);
void wearable_register_identity_callback(wearable_identity_callback_t cb);
void wearable_on_identity_received(const char *name, const char *id_number);

#endif
