/*
 * Ported from official sle_demo_1vn/sle_server.c
 * Adapted to WS63 SDK API.
 */
#include "securec.h"
#include "sle_common.h"
#include "osal_debug.h"
#include "sle_errcode.h"
#include "osal_addr.h"
#include "soc_osal.h"
#include "app_init.h"
#include <string.h>
#include "common_def.h"
#include "sle_connection_manager.h"
#include "sle_device_discovery.h"
#include "../inc/sle_1vn_server_adv.h"
#include "../inc/sle_1vn_server.h"

#define OCTET_BIT_LEN  8
#define UUID_LEN_2     2
#define UUID_INDEX     14

static char     g_sle_uuid_app_uuid[UUID_LEN_2] = {0x12, 0x34};
static char     g_sle_property_value[OCTET_BIT_LEN] = {0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
static uint16_t g_sle_conn_id = 0;
static uint8_t  g_server_id = 0;
static uint16_t g_service_handle = 0;
static uint16_t g_property_handle = 0;

static sle_acb_state_t  g_sle_conn_state = SLE_ACB_STATE_NONE;
static sle_pair_state_t g_sle_pair_state = SLE_PAIR_NONE;

#define UUID_16BIT_LEN  2
#define UUID_128BIT_LEN 16
#define SLE_SERVER_LOG  "[sle 1vn server]"

static uint8_t g_sle_base[] = {
    0x37, 0xBE, 0xA8, 0x80, 0xFC, 0x70, 0x11, 0xEA,
    0xB7, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

static wearable_identity_t g_wearable_identity = {0};
static wearable_identity_callback_t g_wearable_identity_cb = NULL;

static void encode2byte_little(uint8_t *_ptr, uint16_t data)
{
    *(uint8_t *)((_ptr) + 1) = (uint8_t)((data) >> 0x8);
    *(uint8_t *)(_ptr) = (uint8_t)(data);
}

static void sle_uuid_set_base(sle_uuid_t *out)
{
    errcode_t ret;
    ret = memcpy_s(out->uuid, SLE_UUID_LEN, g_sle_base, SLE_UUID_LEN);
    if (ret != EOK) {
        osal_printk("%s sle_uuid_set_base memcpy fail\n", SLE_SERVER_LOG);
        out->len = 0;
        return;
    }
    out->len = UUID_LEN_2;
}

static void sle_uuid_setu2(uint16_t u2, sle_uuid_t *out)
{
    sle_uuid_set_base(out);
    out->len = UUID_LEN_2;
    encode2byte_little(&out->uuid[UUID_INDEX], u2);
}

static void sle_uuid_print(sle_uuid_t *uuid)
{
    if (uuid == NULL) {
        osal_printk("%s uuid is null\r\n", SLE_SERVER_LOG);
        return;
    }
    if (uuid->len == UUID_16BIT_LEN) {
        osal_printk("%s uuid: %02x %02x.\n", SLE_SERVER_LOG,
                    uuid->uuid[14], uuid->uuid[15]);
    } else if (uuid->len == UUID_128BIT_LEN) {
        osal_printk("%s uuid: \n", SLE_SERVER_LOG);
        osal_printk("%s 0x%02x 0x%02x 0x%02x 0x%02x\n", SLE_SERVER_LOG,
                    uuid->uuid[0], uuid->uuid[1], uuid->uuid[2], uuid->uuid[3]);
        osal_printk("%s 0x%02x 0x%02x 0x%02x 0x%02x\n", SLE_SERVER_LOG,
                    uuid->uuid[4], uuid->uuid[5], uuid->uuid[6], uuid->uuid[7]);
        osal_printk("%s 0x%02x 0x%02x 0x%02x 0x%02x\n", SLE_SERVER_LOG,
                    uuid->uuid[8], uuid->uuid[9], uuid->uuid[10], uuid->uuid[11]);
        osal_printk("%s 0x%02x 0x%02x 0x%02x 0x%02x\n", SLE_SERVER_LOG,
                    uuid->uuid[12], uuid->uuid[13], uuid->uuid[14], uuid->uuid[15]);
    }
}

static void ssaps_mtu_changed_cbk(uint8_t server_id, uint16_t conn_id,
    ssap_exchange_info_t *mtu_size, errcode_t status)
{
    osal_printk("%s mtu_changed server_id:%x, conn_id:%x, mtu:%x, status:%x\r\n",
                SLE_SERVER_LOG, server_id, conn_id, mtu_size->mtu_size, status);
}

static void ssaps_start_service_cbk(uint8_t server_id, uint16_t handle, errcode_t status)
{
    osal_printk("%s start_service server_id:%d, handle:%x, status:%x\r\n",
                SLE_SERVER_LOG, server_id, handle, status);
}

static void ssaps_add_service_cbk(uint8_t server_id, sle_uuid_t *uuid,
    uint16_t handle, errcode_t status)
{
    osal_printk("%s add_service server_id:%x, handle:%x, status:%x\r\n",
                SLE_SERVER_LOG, server_id, handle, status);
    sle_uuid_print(uuid);
}

static void ssaps_add_property_cbk(uint8_t server_id, sle_uuid_t *uuid,
    uint16_t service_handle, uint16_t handle, errcode_t status)
{
    osal_printk("%s add_property server_id:%x, svc_handle:%x, handle:%x, status:%x\r\n",
                SLE_SERVER_LOG, server_id, service_handle, handle, status);
    sle_uuid_print(uuid);
}

static void ssaps_add_descriptor_cbk(uint8_t server_id, sle_uuid_t *uuid,
    uint16_t service_handle, uint16_t property_handle, errcode_t status)
{
    osal_printk("%s add_descriptor server_id:%x, svc_handle:%x, prop_handle:%x, status:%x\r\n",
                SLE_SERVER_LOG, server_id, service_handle, property_handle, status);
    sle_uuid_print(uuid);
}

static void ssaps_delete_all_service_cbk(uint8_t server_id, errcode_t status)
{
    osal_printk("%s delete_all_service server_id:%x, status:%x\r\n",
                SLE_SERVER_LOG, server_id, status);
}

static errcode_t sle_uuid_server_service_add(void)
{
    errcode_t ret;
    sle_uuid_t service_uuid = {0};
    sle_uuid_setu2(SLE_UUID_SERVER_SERVICE, &service_uuid);
    ret = ssaps_add_service_sync(g_server_id, &service_uuid, 1, &g_service_handle);
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s add service fail, ret:%x\r\n", SLE_SERVER_LOG, ret);
        return ERRCODE_SLE_FAIL;
    }
    return ERRCODE_SLE_SUCCESS;
}

static errcode_t sle_uuid_server_property_add(void)
{
    errcode_t ret;
    ssaps_property_info_t property = {0};
    ssaps_desc_info_t descriptor = {0};
    uint8_t ntf_value[] = {0x01, 0x02};

    property.permissions = SLE_UUID_TEST_PROPERTIES;
    property.operate_indication = SLE_UUID_TEST_OPERATION_INDICATION;
    sle_uuid_setu2(SLE_UUID_SERVER_NTF_REPORT, &property.uuid);
    property.value_len = OCTET_BIT_LEN;
    property.value = (uint8_t *)osal_vmalloc(sizeof(g_sle_property_value));
    if (property.value == NULL) {
        return ERRCODE_SLE_FAIL;
    }
    if (memcpy_s(property.value, sizeof(g_sle_property_value),
                 g_sle_property_value, sizeof(g_sle_property_value)) != EOK) {
        osal_vfree(property.value);
        return ERRCODE_SLE_FAIL;
    }

    ret = ssaps_add_property_sync(g_server_id, g_service_handle,
                                  &property, &g_property_handle);
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s add property fail, ret:%x\r\n", SLE_SERVER_LOG, ret);
        osal_vfree(property.value);
        return ERRCODE_SLE_FAIL;
    }

    descriptor.permissions = SLE_UUID_TEST_DESCRIPTOR;
    descriptor.type = SSAP_DESCRIPTOR_CLIENT_CONFIGURATION;
    descriptor.operate_indication = SLE_UUID_TEST_OPERATION_INDICATION;
    descriptor.value = (uint8_t *)osal_vmalloc(sizeof(ntf_value));
    if (descriptor.value == NULL) {
        osal_vfree(property.value);
        return ERRCODE_SLE_FAIL;
    }
    if (memcpy_s(descriptor.value, sizeof(ntf_value), ntf_value, sizeof(ntf_value)) != EOK) {
        osal_vfree(property.value);
        osal_vfree(descriptor.value);
        return ERRCODE_SLE_FAIL;
    }

    ret = ssaps_add_descriptor_sync(g_server_id, g_service_handle,
                                    g_property_handle, &descriptor);
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s add descriptor fail, ret:%x\r\n", SLE_SERVER_LOG, ret);
        osal_vfree(property.value);
        osal_vfree(descriptor.value);
        return ERRCODE_SLE_FAIL;
    }

    osal_vfree(property.value);
    osal_vfree(descriptor.value);
    return ERRCODE_SLE_SUCCESS;
}

static errcode_t sle_1vn_server_add(void)
{
    errcode_t ret;
    sle_uuid_t app_uuid = {0};

    osal_printk("%s add service in\r\n", SLE_SERVER_LOG);
    app_uuid.len = sizeof(g_sle_uuid_app_uuid);
    if (memcpy_s(app_uuid.uuid, app_uuid.len, g_sle_uuid_app_uuid,
                 sizeof(g_sle_uuid_app_uuid)) != EOK) {
        return ERRCODE_SLE_FAIL;
    }
    ssaps_register_server(&app_uuid, &g_server_id);

    if (sle_uuid_server_service_add() != ERRCODE_SLE_SUCCESS) {
        ssaps_unregister_server(g_server_id);
        return ERRCODE_SLE_FAIL;
    }
    if (sle_uuid_server_property_add() != ERRCODE_SLE_SUCCESS) {
        ssaps_unregister_server(g_server_id);
        return ERRCODE_SLE_FAIL;
    }
    osal_printk("%s add service, server_id:%x, svc_handle:%x, prop_handle:%x\r\n",
                SLE_SERVER_LOG, g_server_id, g_service_handle, g_property_handle);

    ret = ssaps_start_service(g_server_id, g_service_handle);
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s start service fail, ret:%x\r\n", SLE_SERVER_LOG, ret);
        return ERRCODE_SLE_FAIL;
    }
    osal_printk("%s add service out\r\n", SLE_SERVER_LOG);
    return ERRCODE_SLE_SUCCESS;
}

errcode_t sle_1vn_server_send_notify_by_handle(const uint8_t *data, uint8_t len)
{
    ssaps_ntf_ind_t param = {0};
    param.handle = g_property_handle;
    param.type = SSAP_PROPERTY_TYPE_VALUE;
    param.value_len = len + 1;
    param.value = osal_vmalloc(param.value_len);
    if (param.value == NULL) {
        osal_printk("%s send_notify vmalloc fail\r\n", SLE_SERVER_LOG);
        return ERRCODE_SLE_FAIL;
    }
    if (memcpy_s(param.value, param.value_len, data, len) != EOK) {
        osal_vfree(param.value);
        return ERRCODE_SLE_FAIL;
    }

    if (ssaps_notify_indicate(g_server_id, g_sle_conn_id, &param) != ERRCODE_SUCC) {
        osal_printk("%s ssaps_notify_indicate fail\r\n", SLE_SERVER_LOG);
        osal_vfree(param.value);
        return ERRCODE_SLE_FAIL;
    }
    osal_vfree(param.value);
    return ERRCODE_SLE_SUCCESS;
}

static void sle_connect_state_changed_cbk(uint16_t conn_id, const sle_addr_t *addr,
    sle_acb_state_t conn_state, sle_pair_state_t pair_state, sle_disc_reason_t disc_reason)
{
    g_sle_conn_state = conn_state;

    osal_printk("%s conn_state changed conn_id:0x%02x, conn_state:0x%x, "
                "pair_state:0x%x, disc_reason:0x%x\r\n",
                SLE_SERVER_LOG, conn_id, conn_state, pair_state, disc_reason);
    osal_printk("%s addr:%02x:%02x:%02x:%02x:%02x:%02x\r\n",
                SLE_SERVER_LOG, addr->addr[0], addr->addr[1], addr->addr[2],
                addr->addr[3], addr->addr[4], addr->addr[5]);

    if (conn_state == SLE_ACB_STATE_CONNECTED) {
        g_sle_conn_id = conn_id;
    } else if (conn_state == SLE_ACB_STATE_DISCONNECTED) {
        g_sle_conn_id = 0;
        g_sle_pair_state = SLE_PAIR_NONE;
        errcode_t ret = sle_start_announce(SLE_ADV_HANDLE_DEFAULT);
        if (ret != ERRCODE_SLE_SUCCESS) {
            osal_printk("%s start_announce fail :%x\r\n", SLE_SERVER_LOG, ret);
        }
    }
}

static void sle_pair_complete_cbk(uint16_t conn_id, const sle_addr_t *addr, errcode_t status)
{
    osal_printk("%s pair complete conn_id:%02x, status:%x\r\n", SLE_SERVER_LOG, conn_id, status);
    osal_printk("%s addr:%02x:%02x:%02x:%02x:%02x:%02x\r\n",
                SLE_SERVER_LOG, addr->addr[0], addr->addr[1], addr->addr[2],
                addr->addr[3], addr->addr[4], addr->addr[5]);
    if (status == ERRCODE_SUCC) {
        g_sle_pair_state = SLE_PAIR_PAIRED;
    }
}

static void sle_connect_param_update_req_cbk(uint16_t conn_id, errcode_t status,
    const sle_connection_param_update_req_t *param)
{
    osal_printk("%s param_update_req conn_id:%02x, status:%x, "
                "intv_min:%02x, intv_max:%02x, latency:%02x, timeout:%02x\r\n",
                SLE_SERVER_LOG, conn_id, status, param->interval_min, param->interval_max,
                param->max_latency, param->supervision_timeout);
}

static void sle_connect_param_update_cbk(uint16_t conn_id, errcode_t status,
    const sle_connection_param_update_evt_t *param)
{
    osal_printk("%s param_update conn_id:%02x, status:%x, "
                "interval:%02x, latency:%02x, supervision:%02x\r\n",
                SLE_SERVER_LOG, conn_id, status, param->interval, param->latency, param->supervision);
}

static void sle_auth_complete_cbk(uint16_t conn_id, const sle_addr_t *addr, errcode_t status,
    const sle_auth_info_evt_t *evt)
{
    osal_printk("%s auth complete conn_id:%02x, status:%x\r\n", SLE_SERVER_LOG, conn_id, status);
    osal_printk("%s addr:%02x:%02x:%02x:%02x:%02x:%02x\r\n",
                SLE_SERVER_LOG, addr->addr[0], addr->addr[1], addr->addr[2],
                addr->addr[3], addr->addr[4], addr->addr[5]);
    osal_printk("%s link_key:%02x, crypto_algo:%x, key_deriv_algo:%x, integr_chk:%x\r\n",
                SLE_SERVER_LOG, evt->link_key, evt->crypto_algo, evt->key_deriv_algo,
                evt->integr_chk_ind);
}

static void sle_read_rssi_cbk(uint16_t conn_id, int8_t rssi, errcode_t status)
{
    osal_printk("%s read_rssi conn_id:%02x, rssi:%d, status:%x\r\n",
                SLE_SERVER_LOG, conn_id, rssi, status);
}

static errcode_t sle_1vn_conn_register_cbks(void)
{
    errcode_t ret;
    sle_connection_callbacks_t conn_cbks = {0};
    conn_cbks.connect_state_changed_cb    = sle_connect_state_changed_cbk;
    conn_cbks.connect_param_update_req_cb = sle_connect_param_update_req_cbk;
    conn_cbks.connect_param_update_cb     = sle_connect_param_update_cbk;
    conn_cbks.auth_complete_cb            = sle_auth_complete_cbk;
    conn_cbks.pair_complete_cb            = sle_pair_complete_cbk;
    conn_cbks.read_rssi_cb               = sle_read_rssi_cbk;

    ret = sle_connection_register_callbacks(&conn_cbks);
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s connection_register_callbacks fail :%x\r\n", SLE_SERVER_LOG, ret);
        return ret;
    }
    return ERRCODE_SLE_SUCCESS;
}

static void ssaps_read_request_cbk(uint8_t server_id, uint16_t conn_id,
    ssaps_req_read_cb_t *read_cb_para, errcode_t status)
{
    osal_printk("%s read_request server_id:0x%x, conn_id:0x%x, handle:0x%x, "
                "type:0x%x, status:0x%x\r\n",
                SLE_SERVER_LOG, server_id, conn_id, read_cb_para->handle,
                read_cb_para->type, status);
}

static void ssaps_write_request_cbk(uint8_t server_id, uint16_t conn_id,
    ssaps_req_write_cb_t *write_cb_para, errcode_t status)
{
    (void)server_id;
    (void)conn_id;
    (void)status;
    write_cb_para->value[write_cb_para->length - 1] = '\0';
    osal_printk("%s write_request: %s\r\n", SLE_SERVER_LOG, write_cb_para->value);

    const uint8_t id_prefix[] = {'I', 'D', ':'};
    const uint8_t unbind_prefix[] = {'U', 'N', 'B', 'I', 'N', 'D'};

    if (memcmp(write_cb_para->value, unbind_prefix, 6) == 0) {
        osal_printk("%s ===== UNBIND Request Received =====\r\n", SLE_SERVER_LOG);
        (void)memset_s(&g_wearable_identity, sizeof(wearable_identity_t),
                       0, sizeof(wearable_identity_t));
        osal_printk("%s identity cleared\r\n", SLE_SERVER_LOG);

        char *ack = "UNBOUND";
        sle_1vn_server_send_data((uint8_t *)ack, (uint8_t)strlen(ack));
        osal_printk("%s >>> unbind reply sent\r\n", SLE_SERVER_LOG);
    } else if (memcmp(write_cb_para->value, id_prefix, 3) == 0) {
        char *name_start = (char *)write_cb_para->value + 3;
        char *comma = strstr(name_start, ",");
        char name_buf[WEARABLE_NAME_MAX_LEN] = {0};
        char id_buf[WEARABLE_ID_MAX_LEN] = {0};
        if (comma != NULL) {
            (void)strncpy_s(name_buf, WEARABLE_NAME_MAX_LEN, name_start,
                            (uint32_t)(comma - name_start));
            (void)strncpy_s(id_buf, WEARABLE_ID_MAX_LEN, comma + 1,
                            WEARABLE_ID_MAX_LEN - 1);
        } else {
            (void)strncpy_s(name_buf, WEARABLE_NAME_MAX_LEN, name_start,
                            WEARABLE_NAME_MAX_LEN - 1);
        }
        wearable_on_identity_received(name_buf, id_buf);
        char *ack = "IDENTITY_OK";
        sle_1vn_server_send_data((uint8_t *)ack, (uint8_t)strlen(ack));
    } else {
        char *data = "Response from SLE server!\n";
        sle_1vn_server_send_data((uint8_t *)data, (uint8_t)strlen(data));
    }
}

static errcode_t sle_1vn_ssaps_register_cbks(void)
{
    errcode_t ret;
    ssaps_callbacks_t ssaps_cbk = {0};
    ssaps_cbk.add_service_cb       = ssaps_add_service_cbk;
    ssaps_cbk.add_property_cb      = ssaps_add_property_cbk;
    ssaps_cbk.add_descriptor_cb    = ssaps_add_descriptor_cbk;
    ssaps_cbk.start_service_cb     = ssaps_start_service_cbk;
    ssaps_cbk.delete_all_service_cb = ssaps_delete_all_service_cbk;
    ssaps_cbk.mtu_changed_cb       = ssaps_mtu_changed_cbk;
    ssaps_cbk.read_request_cb      = ssaps_read_request_cbk;
    ssaps_cbk.write_request_cb     = ssaps_write_request_cbk;
    ret = ssaps_register_callbacks(&ssaps_cbk);
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s ssaps_register_callbacks fail :%x\r\n", SLE_SERVER_LOG, ret);
        return ret;
    }
    return ERRCODE_SLE_SUCCESS;
}

errcode_t sle_1vn_server_init(void)
{
    errcode_t ret;

    ret = sle_1vn_announce_register_cbks();
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s announce_register_cbks fail :%x\r\n", SLE_SERVER_LOG, ret);
        return ret;
    }
    ret = sle_1vn_conn_register_cbks();
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s conn_register_cbks fail :%x\r\n", SLE_SERVER_LOG, ret);
        return ret;
    }
    ret = sle_1vn_ssaps_register_cbks();
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s ssaps_register_cbks fail :%x\r\n", SLE_SERVER_LOG, ret);
        return ret;
    }

    ret = enable_sle();
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s enable_sle fail :%x\r\n", SLE_SERVER_LOG, ret);
        return ret;
    }

    osal_printk("%s init ok\r\n", SLE_SERVER_LOG);
    return ERRCODE_SLE_SUCCESS;
}

errcode_t sle_1vn_enable_server_cbk(void)
{
    errcode_t ret;

    ret = sle_1vn_server_add();
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s server_add fail :%x\r\n", SLE_SERVER_LOG, ret);
        return ret;
    }
    ret = sle_1vn_server_adv_init();
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s server_adv_init fail :%x\r\n", SLE_SERVER_LOG, ret);
        return ret;
    }
    return ERRCODE_SLE_SUCCESS;
}

int sle_1vn_server_send_data(uint8_t *data, uint8_t length)
{
    return sle_1vn_server_send_notify_by_handle(data, length);
}

/*
 * 获取当前设备存储的 NFC 身份信息
 */
wearable_identity_t *wearable_get_identity(void)
{
    return &g_wearable_identity;
}

/*
 * 注册身份信息接收回调 (空函数, 待 PN532 就绪后实现)
 */
void wearable_register_identity_callback(wearable_identity_callback_t cb)
{
    g_wearable_identity_cb = cb;
}

/*
 * 身份信息接收处理 (空函数, 待 PN532 就绪后实现)
 * 存储姓名和身份证号到 flash / 内存
 */
void wearable_on_identity_received(const char *name, const char *id_number)
{
    if (name == NULL || id_number == NULL) {
        return;
    }

    (void)strncpy_s(g_wearable_identity.name, WEARABLE_NAME_MAX_LEN,
                    name, WEARABLE_NAME_MAX_LEN - 1);
    (void)strncpy_s(g_wearable_identity.id_number, WEARABLE_ID_MAX_LEN,
                    id_number, WEARABLE_ID_MAX_LEN - 1);
    g_wearable_identity.identity_received = 1;

    osal_printk("%s ===== NFC Identity Stored =====\r\n", SLE_SERVER_LOG);
    osal_printk("%s Name: %s\r\n", SLE_SERVER_LOG, g_wearable_identity.name);
    osal_printk("%s ID:   %s\r\n", SLE_SERVER_LOG, g_wearable_identity.id_number);

    if (g_wearable_identity_cb != NULL) {
        g_wearable_identity_cb(name, id_number);
    }

    char reply[128];
    sprintf_s(reply, sizeof(reply), "CONNECTED:%s,%s", name, id_number);
    sle_1vn_server_send_data((uint8_t *)reply, (uint8_t)strlen(reply));
    osal_printk("%s >>> connected reply sent\r\n", SLE_SERVER_LOG);
}

void sle_1vn_wait_client_paired(void)
{
    while (g_sle_pair_state != SLE_PAIR_PAIRED) {
        osal_msleep(100);
    }
}

void sle_1vn_wait_client_connected(void)
{
    while (g_sle_conn_state != SLE_ACB_STATE_CONNECTED) {
        osal_msleep(100);
    }
}
