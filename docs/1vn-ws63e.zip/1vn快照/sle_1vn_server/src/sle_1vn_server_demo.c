/*
 * Ported from official sle_demo_1vn/sle_server_demo.c
 * Application entry for SLE 1VN Server.
 */
#include <stdio.h>
#include "soc_osal.h"
#include "app_init.h"
#include "common_def.h"
#include "../inc/sle_1vn_server.h"

static int sle_1vn_server_demo_task(const char *arg)
{
    unused(arg);

    osal_printk("=== SLE 1VN Server Demo ===\r\n");

    sle_1vn_server_init();

    while (1) {
        osal_msleep(5000);
        wearable_identity_t *id = wearable_get_identity();
        if (id != NULL && id->identity_received) {
            osal_printk("[demo] identity: %s %s\r\n", id->name, id->id_number);
        } else {
            osal_printk("[demo] server running, no identity yet...\r\n");
        }
    }
    return 0;
}

static void sle_1vn_server_demo_entry(void)
{
    osal_task *task_handle = NULL;
    osal_kthread_lock();
    task_handle = osal_kthread_create((osal_kthread_handler)sle_1vn_server_demo_task, 0,
                                      "sle_1vn_srv", 0x4000);
    if (task_handle != NULL) {
        osal_kthread_set_priority(task_handle, 26);
        osal_kfree(task_handle);
    }
    osal_kthread_unlock();
}

app_run(sle_1vn_server_demo_entry);
