/*
 * Ported from official sle_demo_1vn/sle_server_adv.c
 * Adapted to WS63 SDK API.
 */
#include <string.h>
#include "securec.h"
#include "errcode.h"
#include "osal_addr.h"
#include "sle_common.h"
#include "sle_device_discovery.h"
#include "sle_errcode.h"
#include "osal_debug.h"
#include "soc_osal.h"
#include "../inc/sle_1vn_server.h"
#include "../inc/sle_1vn_server_adv.h"

#define NAME_MAX_LENGTH                     16
#define SLE_CONN_INTV_MIN_DEFAULT           0x64
#define SLE_CONN_INTV_MAX_DEFAULT           0x64
#define SLE_ADV_INTERVAL_MIN_DEFAULT        0xC8
#define SLE_ADV_INTERVAL_MAX_DEFAULT        0xC8
#define SLE_CONN_SUPERVISION_TIMEOUT_DEFAULT 0x1F4
#define SLE_CONN_MAX_LATENCY                0x1F3
#define SLE_ADV_TX_POWER                    10
#define SLE_ADV_DATA_LEN_MAX                251

/*
 * Server MAC address - CHANGE FOR EACH BOARD!
 * Server 1: {|[SYS INFO] mem: used:108068, free:255840; log: drop/all[0/2], at_recv 0.
[demo] identity: G�(]�E��a-�888277364587 
[demo] identity: G�(]�E��a-�888277364587 
APP|[SYS INFO] mem: used:108036, free:255872; log: drop/all[0/2], at_recv 0.
[demo] identity: G�(]�E��a-�888277364587 
[demo] identity: G�(]�E��a-�888277364587 
APP|[SYS INFO] mem: used:108084, free:255824; log: drop/all[0/2], at_recv 0.0x78, 0x70, 0x60, 0x88, 0x96, 0x45}
 * Server 2: {0x78, 0x70, 0x60, 0x88, 0x96, 0x46}
 * Server 3: {0x78, 0x70, 0x60, 0x88, 0x96, 0x47}
 */
#define SLE_SERVER_MAC  {0x78, 0x70, 0x60, 0x88, 0x96, 0x46}

static uint8_t sle_local_name[NAME_MAX_LENGTH] = "sle_server";

#define SLE_SERVER_LOG "[sle 1vn server]"

static uint16_t sle_set_adv_local_name(uint8_t *adv_data, uint16_t max_len)
{
    errno_t ret;
    uint8_t index = 0;
    uint8_t *local_name = sle_local_name;
    uint8_t local_name_len = sizeof(sle_local_name) - 1;
    uint8_t i;

    osal_printk("%s local_name_len = %d\r\n", SLE_SERVER_LOG, local_name_len);
    osal_printk("%s local_name: ", SLE_SERVER_LOG);
    for (i = 0; i < local_name_len; i++) {
        osal_printk("0x%02x ", local_name[i]);
    }
    osal_printk("\r\n");

    adv_data[index++] = local_name_len + 1;
    adv_data[index++] = SLE_ADV_DATA_TYPE_COMPLETE_LOCAL_NAME;
    ret = memcpy_s(&adv_data[index], max_len - index, local_name, local_name_len);
    if (ret != EOK) {
        osal_printk("%s set_adv_local_name memcpy fail\r\n", SLE_SERVER_LOG);
        return 0;
    }
    return (uint16_t)index + local_name_len;
}

static uint16_t sle_set_adv_data(uint8_t *adv_data)
{
    size_t len = 0;
    uint16_t idx = 0;
    errno_t ret = 0;

    len = sizeof(struct sle_adv_common_value);
    struct sle_adv_common_value adv_disc_level = {
        .length = len - 1,
        .type = SLE_ADV_DATA_TYPE_DISCOVERY_LEVEL,
        .value = SLE_ANNOUNCE_LEVEL_NORMAL,
    };
    ret = memcpy_s(&adv_data[idx], SLE_ADV_DATA_LEN_MAX - idx, &adv_disc_level, len);
    if (ret != EOK) {
        osal_printk("%s adv_disc_level memcpy fail\r\n", SLE_SERVER_LOG);
        return 0;
    }
    idx += len;

    len = sizeof(struct sle_adv_common_value);
    struct sle_adv_common_value adv_access_mode = {
        .length = len - 1,
        .type = SLE_ADV_DATA_TYPE_ACCESS_MODE,
        .value = 0,
    };
    ret = memcpy_s(&adv_data[idx], SLE_ADV_DATA_LEN_MAX - idx, &adv_access_mode, len);
    if (ret != EOK) {
        osal_printk("%s adv_access_mode memcpy fail\r\n", SLE_SERVER_LOG);
        return 0;
    }
    idx += len;

    return idx;
}

static uint16_t sle_set_scan_response_data(uint8_t *scan_rsp_data)
{
    uint16_t idx = 0;
    errno_t ret;
    size_t scan_rsp_data_len = sizeof(struct sle_adv_common_value);

    struct sle_adv_common_value tx_power_level = {
        .length = scan_rsp_data_len - 1,
        .type = SLE_ADV_DATA_TYPE_TX_POWER_LEVEL,
        .value = SLE_ADV_TX_POWER,
    };
    ret = memcpy_s(scan_rsp_data, SLE_ADV_DATA_LEN_MAX, &tx_power_level, scan_rsp_data_len);
    if (ret != EOK) {
        osal_printk("%s scan_response_data memcpy fail\r\n", SLE_SERVER_LOG);
        return 0;
    }
    idx += scan_rsp_data_len;

    idx += sle_set_adv_local_name(&scan_rsp_data[idx], SLE_ADV_DATA_LEN_MAX - idx);
    return idx;
}

static int sle_set_default_announce_param(void)
{
    errno_t ret;
    sle_announce_param_t param = {0};
    unsigned char local_addr[SLE_ADDR_LEN] = SLE_SERVER_MAC;

    osal_printk("%s ownAddr: %02x:%02x:%02x:%02x:%02x:%02x\r\n",
                SLE_SERVER_LOG, local_addr[0], local_addr[1], local_addr[2],
                local_addr[3], local_addr[4], local_addr[5]);

    param.announce_mode = SLE_ANNOUNCE_MODE_CONNECTABLE_SCANABLE;
    param.announce_handle = SLE_ADV_HANDLE_DEFAULT;
    param.announce_gt_role = SLE_ANNOUNCE_ROLE_T_CAN_NEGO;
    param.announce_level = SLE_ANNOUNCE_LEVEL_NORMAL;
    param.announce_channel_map = SLE_ADV_CHANNEL_MAP_DEFAULT;
    param.announce_interval_min = SLE_ADV_INTERVAL_MIN_DEFAULT;
    param.announce_interval_max = SLE_ADV_INTERVAL_MAX_DEFAULT;
    param.conn_interval_min = SLE_CONN_INTV_MIN_DEFAULT;
    param.conn_interval_max = SLE_CONN_INTV_MAX_DEFAULT;
    param.conn_max_latency = SLE_CONN_MAX_LATENCY;
    param.conn_supervision_timeout = SLE_CONN_SUPERVISION_TIMEOUT_DEFAULT;
    param.own_addr.type = 0;

    ret = memcpy_s(param.own_addr.addr, SLE_ADDR_LEN, local_addr, SLE_ADDR_LEN);
    if (ret != EOK) {
        osal_printk("%s set_default_announce_param memcpy fail\r\n", SLE_SERVER_LOG);
        return 0;
    }

    return sle_set_announce_param(param.announce_handle, &param);
}

static int sle_set_default_announce_data(void)
{
    errcode_t ret;
    uint8_t announce_data_len = 0;
    uint8_t seek_data_len = 0;
    sle_announce_data_t data = {0};
    uint8_t adv_handle = SLE_ADV_HANDLE_DEFAULT;
    uint8_t announce_data[SLE_ADV_DATA_LEN_MAX] = {0};
    uint8_t seek_rsp_data[SLE_ADV_DATA_LEN_MAX] = {0};
    uint8_t data_index = 0;

    announce_data_len = sle_set_adv_data(announce_data);
    data.announce_data = announce_data;
    data.announce_data_len = announce_data_len;

    osal_printk("%s announce_data_len = %d\r\n", SLE_SERVER_LOG, data.announce_data_len);
    osal_printk("%s announce_data: ", SLE_SERVER_LOG);
    for (data_index = 0; data_index < data.announce_data_len; data_index++) {
        osal_printk("0x%02x ", data.announce_data[data_index]);
    }
    osal_printk("\r\n");

    seek_data_len = sle_set_scan_response_data(seek_rsp_data);
    data.seek_rsp_data = seek_rsp_data;
    data.seek_rsp_data_len = seek_data_len;

    osal_printk("%s seek_rsp_data_len = %d\r\n", SLE_SERVER_LOG, data.seek_rsp_data_len);
    osal_printk("%s seek_rsp_data: ", SLE_SERVER_LOG);
    for (data_index = 0; data_index < data.seek_rsp_data_len; data_index++) {
        osal_printk("0x%02x ", data.seek_rsp_data[data_index]);
    }
    osal_printk("\r\n");

    ret = sle_set_announce_data(adv_handle, &data);
    if (ret == ERRCODE_SLE_SUCCESS) {
        osal_printk("%s set announce data success.\r\n", SLE_SERVER_LOG);
    } else {
        osal_printk("%s set announce data fail.\r\n", SLE_SERVER_LOG);
    }

    return ERRCODE_SLE_SUCCESS;
}

static void sle_announce_enable_cbk(uint32_t announce_id, errcode_t status)
{
    osal_printk("%s announce_enable id:%02x, state:%x\r\n", SLE_SERVER_LOG, announce_id, status);
}

static void sle_announce_disable_cbk(uint32_t announce_id, errcode_t status)
{
    osal_printk("%s announce_disable id:%02x, state:%x\r\n", SLE_SERVER_LOG, announce_id, status);
}

static void sle_announce_terminal_cbk(uint32_t announce_id)
{
    osal_printk("%s announce_terminal id:%02x\r\n", SLE_SERVER_LOG, announce_id);
}

static void sle_enable_cbk(errcode_t status)
{
    osal_printk("%s sle_enable status:%x\r\n", SLE_SERVER_LOG, status);
    sle_1vn_enable_server_cbk();
}

errcode_t sle_1vn_announce_register_cbks(void)
{
    errcode_t ret;
    sle_announce_seek_callbacks_t seek_cbks = {0};
    seek_cbks.announce_enable_cb  = sle_announce_enable_cbk;
    seek_cbks.announce_disable_cb = sle_announce_disable_cbk;
    seek_cbks.announce_terminal_cb = sle_announce_terminal_cbk;
    seek_cbks.sle_enable_cb       = sle_enable_cbk;
    ret = sle_announce_seek_register_callbacks(&seek_cbks);
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s register_callbacks fail :%x\r\n", SLE_SERVER_LOG, ret);
        return ret;
    }
    return ERRCODE_SLE_SUCCESS;
}

errcode_t sle_1vn_server_adv_init(void)
{
    errcode_t ret;

    sle_set_default_announce_param();
    sle_set_default_announce_data();

    ret = sle_start_announce(SLE_ADV_HANDLE_DEFAULT);
    if (ret != ERRCODE_SLE_SUCCESS) {
        osal_printk("%s start_announce fail :%x\r\n", SLE_SERVER_LOG, ret);
        return ret;
    }
    return ERRCODE_SLE_SUCCESS;
}
