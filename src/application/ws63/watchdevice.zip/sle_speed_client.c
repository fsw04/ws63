/**
 * Copyright (c) HiSilicon (Shanghai) Technologies Co., Ltd. 2022. All rights reserved.
 *
 * Description: SLE private service register sample of client.
 */
#include "app_init.h"
#include "systick.h"
#include "tcxo.h"
#include "los_memory.h"
#include "securec.h"
#include "soc_osal.h"
#include "common_def.h"

#include "sle_device_discovery.h"
#include "sle_connection_manager.h"
#include "sle_errcode.h"
#include "sle_ssap_client.h"

#include "sle_speed_client.h"

// 在文件头部引入 Wi-Fi 接口
#include "wifi_device.h"

#undef THIS_FILE_ID
#define THIS_FILE_ID BTH_GLE_SAMPLE_UUID_CLIENT

#define SLE_MTU_SIZE_DEFAULT        1500
#define SLE_SEEK_INTERVAL_DEFAULT   100
#define SLE_SEEK_WINDOW_DEFAULT     100
#define UUID_16BIT_LEN 2
#define UUID_128BIT_LEN 16
#define SLE_SPEED_HUNDRED   100        /* 100  */
#define SPEED_DEFAULT_CONN_INTERVAL 0x14
#define SPEED_DEFAULT_TIMEOUT_MULTIPLIER 0x1f4
#define SPEED_DEFAULT_SCAN_INTERVAL 400
#define SPEED_DEFAULT_SCAN_WINDOW 20

static int g_recv_pkt_num = 0;
static uint64_t g_count_before_get_us;
static uint64_t g_count_after_get_us;

#ifdef CONFIG_LARGE_THROUGHPUT_CLIENT
#define RECV_PKT_CNT 1000
#else
#define RECV_PKT_CNT 1
#endif
#define RSSI_AVG_COUNT 10
static int g_rssi_sum = 0;
static int g_rssi_number = 0;

static sle_announce_seek_callbacks_t g_seek_cbk = {0};
static sle_connection_callbacks_t    g_connect_cbk = {0};
static ssapc_callbacks_t             g_ssapc_cbk = {0};
static sle_addr_t                    g_remote_addr = {0};
static uint16_t                      g_conn_id = 0;
static ssapc_find_service_result_t   g_find_service_result = {0};

void sle_speed_connect_param_init(void)
{
    sle_default_connect_param_t param = {0};
    param.enable_filter_policy = 0;
    param.gt_negotiate = SLE_ANNOUNCE_ROLE_G_CAN_NEGO;
    param.initiate_phys = 1;
    param.max_interval = SPEED_DEFAULT_CONN_INTERVAL;
    param.min_interval = SPEED_DEFAULT_CONN_INTERVAL;
    param.scan_interval = SPEED_DEFAULT_SCAN_INTERVAL;
    param.scan_window = SPEED_DEFAULT_SCAN_WINDOW;
    param.timeout = SPEED_DEFAULT_TIMEOUT_MULTIPLIER;
    sle_default_connection_param_set(&param);
}

void sle_start_scan(void)
{
    sle_seek_param_t param = {0};
    param.own_addr_type = 0;
    param.filter_duplicates = 0;
    param.seek_filter_policy = 0;
    param.seek_phys = 1;
    param.seek_type[0] = 0;
    param.seek_interval[0] = SLE_SEEK_INTERVAL_DEFAULT;
    param.seek_window[0] = SLE_SEEK_WINDOW_DEFAULT;
    sle_set_seek_param(&param);
    sle_start_seek();
}

// void sle_sample_sle_enable_cbk(errcode_t status)
// {
//     if (status == 0) {
//         uint8_t local_addr[SLE_ADDR_LEN] = {0x13, 0x67, 0x5c, 0x07, 0x00, 0x51};
//         sle_addr_t local_address;
//         local_address.type = 0;
//         (void)memcpy_s(local_address.addr, SLE_ADDR_LEN, local_addr, SLE_ADDR_LEN);
//         sle_set_local_addr(&local_address);
//         sle_speed_connect_param_init();
//         sle_start_scan();
//     }
// }

void sle_sample_sle_enable_cbk(errcode_t status)
{
    if (status == 0) {
        sle_addr_t local_address;
        local_address.type = 0;
        
        // 尝试从芯片底层读取出厂的 Base MAC 地址
        int8_t chip_mac[6] = {0};
        errcode_t ret = wifi_get_base_mac_addr(chip_mac, 6);
        
        if (ret == ERRCODE_SUCC) {
            osal_printk("[SLE Client] 成功读取芯片 MAC: %02X:%02X:%02X:%02X:%02X:%02X\r\n", 
                        (uint8_t)chip_mac[0], (uint8_t)chip_mac[1], (uint8_t)chip_mac[2], 
                        (uint8_t)chip_mac[3], (uint8_t)chip_mac[4], (uint8_t)chip_mac[5]);
            (void)memcpy_s(local_address.addr, SLE_ADDR_LEN, chip_mac, SLE_ADDR_LEN);
        } else {
            osal_printk("[SLE Client] 读取芯片 MAC 失败，使用默认随机地址!\r\n");
            // 如果读取失败，使用一个伪随机或者硬编码备用
            uint8_t fallback_addr[SLE_ADDR_LEN] = {0x13, 0x67, 0x5c, 0x07, 0x00, 0x51};
            (void)memcpy_s(local_address.addr, SLE_ADDR_LEN, fallback_addr, SLE_ADDR_LEN);
        }

        sle_set_local_addr(&local_address);
        
        sle_speed_connect_param_init();
        sle_start_scan();
    }
}

void sle_sample_seek_enable_cbk(errcode_t status)
{
    if (status == 0) {
        return;
    }
}

void sle_sample_seek_disable_cbk(errcode_t status)
{
    if (status == 0) {
        sle_connect_remote_device(&g_remote_addr);
    }
}

// void sle_sample_seek_result_info_cbk(sle_seek_result_info_t *seek_result_data)
// {
//     if (seek_result_data != NULL) {
//         uint8_t mac[SLE_ADDR_LEN] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66};
//         if (memcmp(seek_result_data->addr.addr, mac, SLE_ADDR_LEN) == 0) {
//             (void)memcpy_s(&g_remote_addr, sizeof(sle_addr_t), &seek_result_data->addr, sizeof(sle_addr_t));
//             sle_stop_seek();
//         }
//     }
// }

void sle_sample_seek_result_info_cbk(sle_seek_result_info_t *seek_result_data)
{
    if (seek_result_data != NULL) {
        // 原来的死逻辑，现在网关 MAC 变了，我们需要通过寻找特定的 UUID 或者广播名来匹配！       
        // 【修改点】：取消 MAC 强绑定，直接连接扫描到的第一个网关 (对于测试最简单)
        // 或者通过解析 seek_result_data->data 中的名字 "sle_speed_server" 来匹配
        (void)memcpy_s(&g_remote_addr, sizeof(sle_addr_t), &seek_result_data->addr, sizeof(sle_addr_t));
        sle_stop_seek();
    }
}

static uint32_t get_float_int(float in)
{
    return (uint32_t)(((uint64_t)(in * SLE_SPEED_HUNDRED)) / SLE_SPEED_HUNDRED);
}

static uint32_t get_float_dec(float in)
{
    return (uint32_t)(((uint64_t)(in * SLE_SPEED_HUNDRED)) % SLE_SPEED_HUNDRED);
}

static void sle_speed_notification_cb(uint8_t client_id, uint16_t conn_id, ssapc_handle_value_t *data,
    errcode_t status)
{
    unused(client_id);
    unused(status);

    if ((g_recv_pkt_num % RSSI_AVG_COUNT) == 0) {
        sle_read_remote_device_rssi(conn_id); // 用于统计rssi均值
    }
    if (g_recv_pkt_num == 0) {
        g_count_before_get_us = uapi_tcxo_get_us();
    } else if (g_recv_pkt_num == RECV_PKT_CNT) {
        g_count_after_get_us = uapi_tcxo_get_us();
        printf("g_count_after_get_us = %llu, g_count_before_get_us = %llu, data_len = %d\r\n",
            g_count_after_get_us, g_count_before_get_us, data->data_len);
        float time = (float)(g_count_after_get_us - g_count_before_get_us) / 1000000.0;  /* 1s = 1000000.0us */
        printf("time = %d.%d s\r\n", get_float_int(time), get_float_dec(time));
        uint16_t len = data->data_len;
        float speed = len * RECV_PKT_CNT * 8 / time;  /* 1B = 8bits */
        printf("speed = %d.%d bps\r\n", get_float_int(speed), get_float_dec(speed));
        g_recv_pkt_num = 0;
        g_count_before_get_us = g_count_after_get_us;
    }
    g_recv_pkt_num++;
}

static void sle_speed_indication_cb(uint8_t client_id, uint16_t conn_id, ssapc_handle_value_t *data,
    errcode_t status)
{
    unused(status);
    unused(conn_id);
    unused(client_id);
    osal_printk("\n sle_speed_indication_cb sle uart recived data : %s\r\n", data->data);
}

void sle_sample_seek_cbk_register(void)
{
    g_seek_cbk.sle_enable_cb = sle_sample_sle_enable_cbk;
    g_seek_cbk.seek_enable_cb = sle_sample_seek_enable_cbk;
    g_seek_cbk.seek_disable_cb = sle_sample_seek_disable_cbk;
    g_seek_cbk.seek_result_cb = sle_sample_seek_result_info_cbk;
}

void sle_sample_connect_state_changed_cbk(uint16_t conn_id, const sle_addr_t *addr,
    sle_acb_state_t conn_state, sle_pair_state_t pair_state, sle_disc_reason_t disc_reason)
{
    osal_printk("[ssap client] conn state changed conn_id:%d, addr:0x%02x:**:**:0x%02x:0x%02x\n",
        conn_id, addr->addr[0], addr->addr[4], addr->addr[5]); /* 0 4 5: addr index */
    osal_printk("[ssap client] conn state changed disc_reason:0x%x, pair_state:0x%x, conn_state:0x%x\n",
        disc_reason, pair_state, conn_state);
    if (conn_state == SLE_ACB_STATE_CONNECTED) {
        if (pair_state == SLE_PAIR_NONE) {
            sle_pair_remote_device(&g_remote_addr);
        }
        g_conn_id = conn_id;
    } else if (conn_state == SLE_ACB_STATE_DISCONNECTED) {
        sle_start_scan();
        g_recv_pkt_num = 0;
    }
}

void sle_sample_auth_complete_cbk(uint16_t conn_id, const sle_addr_t *addr, errcode_t status,
    const sle_auth_info_evt_t* evt)
{
    unused(conn_id);
    unused(evt);
    osal_printk("[speed server] auth cmp:0x%x\r\n", status);
    if (status == ERRCODE_SLE_SUCCESS) {
        return;
    }
    osal_printk("[speed server] auth failed, remove pair and restart scan\r\n");
    sle_remove_paired_remote_device(addr);
    sle_start_scan();
}

void sle_sample_pair_complete_cbk(uint16_t conn_id, const sle_addr_t *addr, errcode_t status)
{
    osal_printk("[ssap client] pair complete conn_id:%d, addr:0x%02x:**:**:0x%02x:0x%02x, status:0x%x\n",
        conn_id, addr->addr[0], addr->addr[4], addr->addr[5], status); /* 0 4 5: addr index */
    if (status == ERRCODE_SLE_SUCCESS) {
        ssap_exchange_info_t info = {0};
        info.mtu_size = SLE_MTU_SIZE_DEFAULT;
        info.version = 1;
        ssapc_exchange_info_req(1, g_conn_id, &info);
        return;
    }
    osal_printk("[speed server] pair failed, remove pair and restart scan\r\n");
    sle_remove_paired_remote_device(addr);
    sle_start_scan();
}

void sle_sample_update_cbk(uint16_t conn_id, errcode_t status, const sle_connection_param_update_evt_t *param)
{
    unused(status);
    osal_printk("[ssap client] updat state changed conn_id:%d, interval = 0x%02x\n", conn_id, param->interval);
}

void sle_sample_update_req_cbk(uint16_t conn_id, errcode_t status, const sle_connection_param_update_req_t *param)
{
    unused(conn_id);
    unused(status);
    osal_printk("[ssap client] sle_sample_update_req_cbk interval_min = 0x%02x, interval_max = 0x%02x\n",
        param->interval_min, param->interval_max);
}

void sle_sample_read_rssi_cbk(uint16_t conn_id, int8_t rssi, errcode_t status)
{
    unused(conn_id);
    unused(status);
    g_rssi_sum = g_rssi_sum + rssi;
    g_rssi_number++;
    if (g_rssi_number == RSSI_AVG_COUNT) {
        osal_printk("rssi average = %d dbm\r\n", g_rssi_sum / g_rssi_number);
        g_rssi_sum = 0;
        g_rssi_number = 0;
    }
}

void sle_sample_connect_cbk_register(void)
{
    g_connect_cbk.connect_state_changed_cb = sle_sample_connect_state_changed_cbk;
    g_connect_cbk.auth_complete_cb = sle_sample_auth_complete_cbk;
    g_connect_cbk.pair_complete_cb = sle_sample_pair_complete_cbk;
    g_connect_cbk.connect_param_update_req_cb = sle_sample_update_req_cbk;
    g_connect_cbk.connect_param_update_cb = sle_sample_update_cbk;
    g_connect_cbk.read_rssi_cb = sle_sample_read_rssi_cbk;
}

void sle_sample_exchange_info_cbk(uint8_t client_id, uint16_t conn_id, ssap_exchange_info_t *param,
    errcode_t status)
{
    osal_printk("[ssap client] pair complete client id:%d status:%d\n", client_id, status);
    osal_printk("[ssap client] exchange mtu, mtu size: %d, version: %d.\n",
        param->mtu_size, param->version);

    ssapc_find_structure_param_t find_param = {0};
    find_param.type = SSAP_FIND_TYPE_PRIMARY_SERVICE;
    find_param.start_hdl = 1;
    find_param.end_hdl = 0xFFFF;
    ssapc_find_structure(0, conn_id, &find_param);
}

void sle_sample_find_structure_cbk(uint8_t client_id, uint16_t conn_id, ssapc_find_service_result_t *service,
    errcode_t status)
{
    osal_printk("[ssap client] find structure cbk client: %d conn_id:%d status: %d \n",
        client_id, conn_id, status);
    osal_printk("[ssap client] find structure start_hdl:[0x%02x], end_hdl:[0x%02x], uuid len:%d\r\n",
        service->start_hdl, service->end_hdl, service->uuid.len);
    if (service->uuid.len == UUID_16BIT_LEN) {
        osal_printk("[ssap client] structure uuid:[0x%02x][0x%02x]\r\n",
            service->uuid.uuid[14], service->uuid.uuid[15]); /* 14 15: uuid index */
    } else {
        for (uint8_t idx = 0; idx < UUID_128BIT_LEN; idx++) {
            osal_printk("[ssap client] structure uuid[%d]:[0x%02x]\r\n", idx, service->uuid.uuid[idx]);
        }
    }
    g_find_service_result.start_hdl = service->start_hdl;
    g_find_service_result.end_hdl = service->end_hdl;
    if (memcpy_s(&g_find_service_result.uuid, sizeof(sle_uuid_t), &service->uuid, sizeof(sle_uuid_t)) != EOK) {
        osal_printk("[ssap client] find structure mem cpy failed");
        return;
    }
}

// void sle_sample_find_structure_cmp_cbk(uint8_t client_id, uint16_t conn_id,
//     ssapc_find_structure_result_t *structure_result, errcode_t status)
// {
//     osal_printk("[ssap client] find structure cmp cbk client id:%d status:%d type:%d uuid len:%d \r\n",
//         client_id, status, structure_result->type, structure_result->uuid.len);
//     if (structure_result->uuid.len == UUID_16BIT_LEN) {
//         osal_printk("[ssap client] find structure cmp cbk structure uuid:[0x%02x][0x%02x]\r\n",
//             structure_result->uuid.uuid[14], structure_result->uuid.uuid[15]); /* 14 15: uuid index */
//     } else {
//         for (uint8_t idx = 0; idx < UUID_128BIT_LEN; idx++) {
//             osal_printk("[ssap client] find structure cmp cbk structure uuid[%d]:[0x%02x]\r\n", idx,
//                 structure_result->uuid.uuid[idx]);
//         }
//     }
//     uint8_t data[] = {0x11, 0x22, 0x33, 0x44};
//     uint8_t len = sizeof(data);
//     ssapc_write_param_t param = {0};
//     param.handle = g_find_service_result.start_hdl;
//     param.type = SSAP_PROPERTY_TYPE_VALUE;
//     param.data_len = len;
//     param.data = data;
//     ssapc_write_req(0, conn_id, &param);
// }

void sle_sample_find_structure_cmp_cbk(uint8_t client_id, uint16_t conn_id,
    ssapc_find_structure_result_t *structure_result, errcode_t status)
{
    (void)conn_id;

    osal_printk("[ssap client] find structure cmp cbk client id:%d status:%d type:%d uuid len:%d \r\n",
        client_id, status, structure_result->type, structure_result->uuid.len);
    if (structure_result->uuid.len == UUID_16BIT_LEN) {
        osal_printk("[ssap client] find structure cmp cbk structure uuid:[0x%02x][0x%02x]\r\n",
            structure_result->uuid.uuid[14], structure_result->uuid.uuid[15]);
    } else {
        for (uint8_t idx = 0; idx < UUID_128BIT_LEN; idx++) {
            osal_printk("[ssap client] find structure cmp cbk structure uuid[%d]:[0x%02x]\r\n", idx,
                structure_result->uuid.uuid[idx]);
        }
    }
    
    osal_printk("[ssap client] 服务结构寻找完成，准备就绪，可以发送数据了！\r\n");
}


void sle_sample_find_property_cbk(uint8_t client_id, uint16_t conn_id,
    ssapc_find_property_result_t *property, errcode_t status)
{
    osal_printk("[ssap client] find property cbk, client id: %d, conn id: %d, operate ind: %d, "
        "descriptors count: %d status:%d.\n", client_id, conn_id, property->operate_indication,
        property->descriptors_count, status);
    for (uint16_t idx = 0; idx < property->descriptors_count; idx++) {
        osal_printk("[ssap client] find property cbk, descriptors type [%d]: 0x%02x.\n",
            idx, property->descriptors_type[idx]);
    }
    if (property->uuid.len == UUID_16BIT_LEN) {
        osal_printk("[ssap client] find property cbk, uuid: 0x%02x %02x.\n",
            property->uuid.uuid[14], property->uuid.uuid[15]); /* 14 15: uuid index */
    } else if (property->uuid.len == UUID_128BIT_LEN) {
        for (uint16_t idx = 0; idx < UUID_128BIT_LEN; idx++) {
            osal_printk("[ssap client] find property cbk, uuid [%d]: 0x%02x.\n",
                idx, property->uuid.uuid[idx]);
        }
    }
}

// void sle_sample_write_cfm_cbk(uint8_t client_id, uint16_t conn_id, ssapc_write_result_t *write_result,
//     errcode_t status)
// {
//     osal_printk("[ssap client] write cfm cbk, client id: %d status:%d.\n", client_id, status);
//     // server端在接收到read_req消息后，会创建一个发包线程
//     ssapc_read_req(0, conn_id, write_result->handle, write_result->type);
// }

void sle_sample_write_cfm_cbk(uint8_t client_id, uint16_t conn_id, ssapc_write_result_t *write_result,
    errcode_t status)
{
    (void)conn_id;       
    (void)write_result; 

    osal_printk("[ssap client] write cfm cbk, client id: %d status:%d.\n", client_id, status);
}

void sle_sample_read_cfm_cbk(uint8_t client_id, uint16_t conn_id, ssapc_handle_value_t *read_data,
    errcode_t status)
{
    osal_printk("[ssap client] read cfm cbk client id: %d conn id: %d status: %d\n",
        client_id, conn_id, status);
    osal_printk("[ssap client] read cfm cbk handle: %d, type: %d , len: %d\n",
        read_data->handle, read_data->type, read_data->data_len);
    for (uint16_t idx = 0; idx < read_data->data_len; idx++) {
        osal_printk("[ssap client] read cfm cbk[%d] 0x%02x\r\n", idx, read_data->data[idx]);
    }
}

void sle_sample_ssapc_cbk_register(ssapc_notification_callback notification_cb,
    ssapc_notification_callback indication_cb)
{
    g_ssapc_cbk.exchange_info_cb = sle_sample_exchange_info_cbk;
    g_ssapc_cbk.find_structure_cb = sle_sample_find_structure_cbk;
    g_ssapc_cbk.find_structure_cmp_cb = sle_sample_find_structure_cmp_cbk;
    g_ssapc_cbk.ssapc_find_property_cbk = sle_sample_find_property_cbk;
    g_ssapc_cbk.write_cfm_cb = sle_sample_write_cfm_cbk;
    g_ssapc_cbk.read_cfm_cb = sle_sample_read_cfm_cbk;
    g_ssapc_cbk.notification_cb = notification_cb;
    g_ssapc_cbk.indication_cb = indication_cb;
}

void sle_client_init(ssapc_notification_callback notification_cb, ssapc_indication_callback indication_cb)
{
    sle_sample_seek_cbk_register();
    sle_sample_connect_cbk_register();
    sle_sample_ssapc_cbk_register(notification_cb, indication_cb);
    sle_announce_seek_register_callbacks(&g_seek_cbk);
    sle_connection_register_callbacks(&g_connect_cbk);
    ssapc_register_callbacks(&g_ssapc_cbk);
    enable_sle();
}

int sle_speed_init(void)
{
    osal_msleep(1000);  /* sleep 1000ms */
    sle_client_init(sle_speed_notification_cb, sle_speed_indication_cb);
    return 0;
}

#define SLE_SPEED_TASK_PRIO 26
#define SLE_SPEED_STACK_SIZE 0x2000
static void sle_speed_entry(void)
{
    osal_task *task_handle = NULL;
    osal_kthread_lock();
    task_handle = osal_kthread_create((osal_kthread_handler)sle_speed_init, 0, "ThroughputTask", SLE_SPEED_STACK_SIZE);
    if (task_handle != NULL) {
        osal_kthread_set_priority(task_handle, SLE_SPEED_TASK_PRIO);
        osal_kfree(task_handle);
    }
    osal_kthread_unlock();
}

// 提供给 sensor_task.c 调用的发送接口
int sle_client_send_data(const char *payload, uint16_t len)
{
    // 直接强制使用网关固定的特征句柄 17 (0x11)
    uint16_t target_handle = 17; 

    // 参数依然使用标准的 SSAP_PROPERTY_TYPE_VALUE
    ssapc_write_param_t param = { 0 };
    param.handle = target_handle;
    param.type = SSAP_PROPERTY_TYPE_VALUE; // 这个不用变，就用 VALUE
    param.data_len = len;
    param.data = (uint8_t *)payload;

    // 【核心修改】：把原来的 ssapc_write_req 换成 ssapc_write_cmd！
    // ssapc_write_cmd 是“无响应写入”，它不要求服务端必须拥有强写入权限，也不会触发 ACK 等待。
    errcode_t ret = ssapc_write_cmd(0, g_conn_id, &param);
    return ret;
}

/* Run the blinky_entry. */
app_run(sle_speed_entry);